go
create or alter proc sp_Login
    @usuario VARCHAR(255),
    @contrasena VARCHAR(255)
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (SELECT 1 FROM usuarios WHERE usuario = @usuario AND contrasena = @contrasena)
    BEGIN
		IF EXISTS (SELECT 1 FROM usuarios WHERE usuario = @usuario AND contrasena = @contrasena)
		BEGIN
			SELECT '1' AS Resultado;
		END
		ELSE
		BEGIN
			SELECT '2' AS Resultado;
		END
    END
    ELSE
    BEGIN
        SELECT 'El usuario no existe' AS error;
    END
END;
go
