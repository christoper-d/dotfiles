CREATE OR ALTER PROC sp_crear_usuario
    @nombre VARCHAR(250),
    @usuario VARCHAR(250),
    @contrasena VARCHAR(250),
	@puesto VARCHAR(250),
	@area_asignada VARCHAR(250),
    @administrador_id int
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM usuarios WHERE usuario = @usuario)
    BEGIN
        INSERT INTO usuarios (nombre, usuario, contrasena, puesto, area_asignada, administrador_id)
        VALUES (@Nombre, @Usuario, @Contrasena, @Puesto, @AreaAsignada, @AdministradorID);

        SELECT 'Usuario creado' AS Resultado;
    END
    ELSE
    BEGIN
        SELECT 'Usuario ya existe' AS Resultado;
    END
END;
