import re
from datetime import datetime

def generar_resultado(cadena):
    # Extraer los primeros dígitos de cada palabra que comienza con un número
    digitos = ''.join(re.findall(r'\b\d', cadena))

    # Obtener el nombre del mes actual en mayúsculas
    nombre_mes = datetime.now().strftime('%B').upper()

    # Crear el resultado con el formato deseado
    resultado = f'{digitos}{nombre_mes}-{digitos.zfill(2)}'

    return resultado

# Ejemplo de uso
cadena_entrada = input(">")
resultado = generar_resultado(cadena_entrada)
print(resultado)
