DROP TABLE IF EXISTS buzon, solicitudes, registros, clientes, estados, usuarios;

-- Tabla usuarios
CREATE TABLE usuarios (
    usuario_id INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
    nombre VARCHAR(255),
    usuario VARCHAR(250) UNIQUE NOT NULL,
    contrasena VARCHAR(250) NOT NULL,
    puesto VARCHAR(250),
    area_asignada VARCHAR(250),
    administrador_id INT,
    CONSTRAINT FK_administrador_id FOREIGN KEY (administrador_id) REFERENCES usuarios(usuario_id)
);

-- Tabla solicitudes
CREATE TABLE solicitudes (
    solicitud_id INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
    solicitud VARCHAR(250) NOT NULL
);

-- Tabla buzon
CREATE TABLE buzon (
    buzon_id INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
    usuario_id INT NOT NULL,
    solicitud_id INT NOT NULL,
    CONSTRAINT FK_usuario_id_buzon FOREIGN KEY (usuario_id) REFERENCES usuarios(usuario_id) ON DELETE CASCADE,
    CONSTRAINT FK_solicitud_id_buzon FOREIGN KEY (solicitud_id) REFERENCES solicitudes(solicitud_id) ON DELETE CASCADE
);

-- Tabla clientes
CREATE TABLE clientes (
    ruc VARCHAR(50) PRIMARY KEY NOT NULL,
    nombre VARCHAR(250) NOT NULL,
    ubicacion VARCHAR(250) NOT NULL,
    telefono VARCHAR(15) NOT NULL,
    usuario_id INT NOT NULL,
    CONSTRAINT FK_usuario_id_clientes FOREIGN KEY (usuario_id) REFERENCES usuarios(usuario_id) ON DELETE CASCADE
);

-- Tabla estados
CREATE TABLE estados (
    estado_id INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
    estado VARCHAR(250) NOT NULL
);

-- Tabla registros
CREATE TABLE registros (
    registro_id INT PRIMARY KEY NOT NULL,
    ruc char(50) NOT NULL,
    usuario_id INT NOT NULL,
    estado_id INT NOT NULL,
    CONSTRAINT FK_ruc_registros FOREIGN KEY (ruc) REFERENCES clientes(ruc),
    CONSTRAINT FK_usuario_id_registros FOREIGN KEY (usuario_id) REFERENCES usuarios(usuario_id) ON DELETE CASCADE,
    CONSTRAINT FK_estado_id_registros FOREIGN KEY (estado_id) REFERENCES estados(estado_id) ON DELETE CASCADE
);

-- Inserciones para la tabla usuarios
INSERT INTO usuarios (nombre, usuario, contrasena, puesto, area_asignada, administrador_id)
VALUES 
('', 'admin', '$2b$12$8Y4BVVbCYRXwJbn5oL85TOyEsl2u7Gcl3FdrrNWqlpRRGwPDmJJ/6', 'sistemas', 'sistemas', 1),
('', 'admin2', '$2b$12$EFWTibbgaPAYOtsFinFqJ.e3sGQWoz4Wr0ClcbI7U7ZMaLqAjNuwi', 'sistemas', 'sistemas', 2),
('Christoper sanchez', 'chris', '123', 'sistemas', 'sistemas', NULL);

-- Inserciones para la tabla solicitudes
INSERT INTO solicitudes (solicitud)
VALUES 
('Cambio de contraseña'),
('Olvido de contraseña');

INSERT INTO clientes (ruc, nombre, ubicacion, telefono, usuario_id)
VALUES 
('20601860806', 'INVERSIONES Y REPRESENTACIONES POLLOS A LA BRASA EL CHINO S.A.C. - INREPOBRACHI S.A.C.', 'AV. LAZARO CARRILLO NRO. 151 (FT PARQUE HUARMACUYAY C4P CL AMARILLO) APURIMAC - ANDAHUAYLAS - ANDAHUAYLAS', '123-456-7890', 1);


-- Inserciones para la tabla estados
INSERT INTO estados (estado)
VALUES 
('Por recoger'),
('Por contabilizar'),
('Por entregar'),
('Completado');

select * from solicitudes;
select * from usuarios;
select * from clientes;-- Inserciones para la tabla usuarios


-- Inserciones para la tabla buzon
-- INSERT INTO buzon (usuario_id, solicitud_id)
-- VALUES 
-- (1, 1),
-- (2, 2),
-- (3, 3);

-- Inserciones para la tabla registros
INSERT INTO registros (registro_id, ruc, usuario_id, estado_id)
VALUES 
(1, 123456789, 1, 1),
(2, 987654321, 2, 2),
(3, 555555555, 3, 3);
