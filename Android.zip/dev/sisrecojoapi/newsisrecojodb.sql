DROP TABLE IF EXISTS buzon, solicitudes, registros, clientes, estados, usuarios;

-- Tabla usuarios
CREATE TABLE usuarios (
    usuario_id INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
    nombre VARCHAR(255),
    usuario VARCHAR(250) UNIQUE NOT NULL,
    contrasena VARCHAR(250) NOT NULL,
    puesto VARCHAR(250),
    area_asignada VARCHAR(250),
    administrador_id INT,
    CONSTRAINT FK_administrador_id FOREIGN KEY (administrador_id) REFERENCES usuarios(usuario_id)
);

-- Tabla solicitudes
CREATE TABLE solicitudes (
    solicitud_id INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
    solicitud VARCHAR(250) NOT NULL
);

-- Tabla buzon
CREATE TABLE buzon (
    buzon_id INT PRIMARY KEY NOT NULL,
	admin_id int NOT NULL,
    usuario_id INT NOT NULL,
    solicitud_id INT NOT NULL,
	CONSTRAINT FK_admin_id_buzon FOREIGN KEY (admin_id) REFERENCES usuarios(usuario_id) ON DELETE CASCADE,
    CONSTRAINT FK_usuario_id_buzon FOREIGN KEY (usuario_id) REFERENCES usuarios(usuario_id) ON DELETE NO ACTION,
    CONSTRAINT FK_solicitud_id_buzon FOREIGN KEY (solicitud_id) REFERENCES solicitudes(solicitud_id) ON DELETE CASCADE
);

-- Tabla clientes
CREATE TABLE clientes (
    ruc BIGINT PRIMARY KEY NOT NULL,
    nombre VARCHAR(250) NOT NULL,
    ubicacion VARCHAR(250) NOT NULL,
    telefono VARCHAR(15) NOT NULL,
    usuario_id INT NOT NULL,
    CONSTRAINT FK_usuario_id_clientes FOREIGN KEY (usuario_id) REFERENCES usuarios(usuario_id) ON DELETE NO ACTION
);

-- Tabla estados
CREATE TABLE estados (
    estado_id INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
    estado VARCHAR(250) NOT NULL
);

-- Tabla registros
CREATE TABLE registros (
    registro_id VARCHAR(50) PRIMARY KEY NOT NULL,
    ruc BIGINT NOT NULL,
    mes VARCHAR(50),
    usuario_id INT NOT NULL,
    estado_id INT NOT NULL,
	fecha_cambio DATETIME,
    CONSTRAINT FK_ruc_registros FOREIGN KEY (ruc) REFERENCES clientes(ruc) ON DELETE CASCADE,
    CONSTRAINT FK_usuario_id_registros FOREIGN KEY (usuario_id) REFERENCES usuarios(usuario_id) ON DELETE CASCADE,
    CONSTRAINT FK_estado_id_registros FOREIGN KEY (estado_id) REFERENCES estados(estado_id) ON DELETE CASCADE
);

-- Inserciones para la tabla estados
INSERT INTO estados (estado)
VALUES 
('Por recoger'),
('Por contabilizar'),
('Por entregar'),
('Completado');

-- Inserciones para la tabla solicitudes
INSERT INTO solicitudes (solicitud)
VALUES 
('Cambio de contraseña'),
('Olvido de contraseña');