// const res = prueba();

// res.then(response => response.json())
//    .then(data => console.log(data))
//    .catch(error => console.error('Error:', error));

// function prueba() {
//     // Disable certificate validation for development purposes
//     // process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

//     return fetch("https://localhost:7068/api/Buzon/all", {
//         "headers": {
//           "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
//           "accept-language": "es-419,es;q=0.9",
//           "cache-control": "max-age=0",
//           "sec-ch-ua": "\"Not_A Brand\";v=\"8\", \"Chromium\";v=\"120\", \"Google Chrome\";v=\"120\"",
//           "sec-ch-ua-mobile": "?0",
//           "sec-ch-ua-platform": "\"Windows\"",
//           "sec-fetch-dest": "document",
//           "sec-fetch-mode": "navigate",
//           "sec-fetch-site": "none",
//           "sec-fetch-user": "?1",
//           "upgrade-insecure-requests": "1"
//         },
//         "referrerPolicy": "strict-origin-when-cross-origin",
//         "body": null,
//         "method": "GET"
//       });
// }

// function prueba() {
//     // Disable certificate validation for development purposes
//     process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

//     return fetch("https://localhost:7068/api/Usuario/all", {
//         "headers": {
//             "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
//             "accept-language": "es-419,es;q=0.9",
//             "cache-control": "max-age=0",
//             "sec-ch-ua": "\"Not_A Brand\";v=\"8\", \"Chromium\";v=\"120\", \"Google Chrome\";v=\"120\"",
//             "sec-ch-ua-mobile": "?0",
//             "sec-ch-ua-platform": "\"Windows\"",
//             "sec-fetch-dest": "document",
//             "sec-fetch-mode": "navigate",
//             "sec-fetch-site": "none",
//             "sec-fetch-user": "?1",
//             "upgrade-insecure-requests": "1"
//         },
//         "referrerPolicy": "strict-origin-when-cross-origin",
//         "method": "GET",
//         "mode": "cors",
//         "credentials": "omit"
//     });
// }


// si funciona 

var url = "https://localhost:7068/api/Buzon/all";

fetch(url, {
  method: "GET",
  body: null,
  headers: {
    "Content-Type": "application/json",
  }
})
  .then((res) => res.json())
  .catch((error) => console.error("Error:", error))
  .then((response) => console.log("Success:", response));

// const https = require('https');

// const url = "https://localhost:7068/api/Buzon/all";

// const options = {
//   method: "GET",
//   headers: {
//     "Content-Type": "application/json",
//   },
//   agent: new https.Agent({
//     rejectUnauthorized: false
//   })
// };

// https.get(url, options, (response) => {
//   let data = '';

//   // Recibir los datos en trozos
//   response.on('data', (chunk) => {
//     data += chunk;
//   });

//   // La solicitud ha terminado, procesar los datos
//   response.on('end', () => {
//     console.log(data);
//   });
// }).on('error', (error) => {
//   console.error(`Error al realizar la solicitud: ${error.message}`);
// });

// const fetch = require('node-fetch');

// const url = 'https://localhost:7068/api/Usuario/SignIn';

// const data = {
//   usuario: 'admin',
//   contrasena: '123'
// };

// fetch(url, {
//   method: 'POST',
//   headers: {
//     'Content-Type': 'application/json',
//   },
//   body: JSON.stringify(data),
//   agent: new (require('https')).Agent({
//     rejectUnauthorized: false
//   })
// })
//   .then(response => {
//     if (!response.ok) {
//       throw new Error(`HTTP error! Status: ${response.status}`);
//     }
//     return response.json();
//   })
//   .then(responseData => {
//     console.log('Success:', responseData);
//   })
//   .catch(error => {
//     console.error('Error:', error.message);
//   });
