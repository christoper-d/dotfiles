fetch("http://localhost:5064/api/Registro/PS-20240201")
  .then((res) => res.json())
  .then((response) => console.log("Success:", response))
  .catch((error) => console.error("Error:", error));
