﻿namespace login
{
    partial class main
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.controles = new System.Windows.Forms.TabControl();
            this.tabHome1 = new System.Windows.Forms.TabPage();
            this.label15 = new System.Windows.Forms.Label();
            this.btnMoverAgestionEliminarEmpresa = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.btnMoverAgestionCrearEmpresa = new System.Windows.Forms.Button();
            this.lbUser1 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.lbidkssss = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.treeFiles = new System.Windows.Forms.TreeView();
            this.tabSubirArchivos = new System.Windows.Forms.TabPage();
            this.label16 = new System.Windows.Forms.Label();
            this.comboxEmpresasUploadFile = new System.Windows.Forms.ComboBox();
            this.btnUpdateUserFiles = new System.Windows.Forms.Button();
            this.filesForUser = new System.Windows.Forms.DataGridView();
            this.btnSubir = new System.Windows.Forms.Button();
            this.txtRuta = new System.Windows.Forms.TextBox();
            this.btnSelect = new System.Windows.Forms.Button();
            this.tabGestionUsuarios = new System.Windows.Forms.TabPage();
            this.panel3 = new System.Windows.Forms.Panel();
            this.allUsers = new System.Windows.Forms.DataGridView();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.tabControlToAdmin = new System.Windows.Forms.TabControl();
            this.tabHome = new System.Windows.Forms.TabPage();
            this.stateDb = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.tabCrearUsuario = new System.Windows.Forms.TabPage();
            this.comBoxAcceso = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.comBoxPermisos = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtUserPasswordToNewUser = new System.Windows.Forms.TextBox();
            this.txtUserNameToNewUser = new System.Windows.Forms.TextBox();
            this.btnCrearUsuario = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tabEditar = new System.Windows.Forms.TabPage();
            this.btnEditarCancelar = new System.Windows.Forms.Button();
            this.comBoxEditarAcceso = new System.Windows.Forms.ComboBox();
            this.lbForEditarAcceso = new System.Windows.Forms.Label();
            this.lbForEdit = new System.Windows.Forms.Label();
            this.btnBuscarUsuario = new System.Windows.Forms.Button();
            this.txtForMessageEditar = new System.Windows.Forms.Label();
            this.comBoxEditarPermisos = new System.Windows.Forms.ComboBox();
            this.lbForEditarPermisos = new System.Windows.Forms.Label();
            this.txtEditPassword = new System.Windows.Forms.TextBox();
            this.txtEditName = new System.Windows.Forms.TextBox();
            this.btnGuardarCambios = new System.Windows.Forms.Button();
            this.lbForEditarName = new System.Windows.Forms.Label();
            this.lbForEditarPassword = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtIdEditar = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tabEliminarUsuario = new System.Windows.Forms.TabPage();
            this.label6 = new System.Windows.Forms.Label();
            this.btnEliminarUser = new System.Windows.Forms.Button();
            this.txtUserId = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPageEmpresas = new System.Windows.Forms.TabPage();
            this.tabControlToGestionDeEmpresas = new System.Windows.Forms.TabControl();
            this.tabcrearEmpresa = new System.Windows.Forms.TabPage();
            this.btnCrearEmpresa = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.txtCrearEmpresa = new System.Windows.Forms.TextBox();
            this.tabeliminarEmpresa = new System.Windows.Forms.TabPage();
            this.btnEliminarEmpresa = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.txtEliminarEmpresa = new System.Windows.Forms.TextBox();
            this.btnActualizarEmpresas = new System.Windows.Forms.Button();
            this.dataGridViewforAllEmpresas = new System.Windows.Forms.DataGridView();
            this.btnCerrarSesion = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnSalir = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.btnMoverAfiles = new System.Windows.Forms.Button();
            this.controles.SuspendLayout();
            this.tabHome1.SuspendLayout();
            this.tabSubirArchivos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.filesForUser)).BeginInit();
            this.tabGestionUsuarios.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.allUsers)).BeginInit();
            this.tabControlToAdmin.SuspendLayout();
            this.tabHome.SuspendLayout();
            this.tabCrearUsuario.SuspendLayout();
            this.tabEditar.SuspendLayout();
            this.tabEliminarUsuario.SuspendLayout();
            this.tabPageEmpresas.SuspendLayout();
            this.tabControlToGestionDeEmpresas.SuspendLayout();
            this.tabcrearEmpresa.SuspendLayout();
            this.tabeliminarEmpresa.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewforAllEmpresas)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // controles
            // 
            this.controles.Controls.Add(this.tabHome1);
            this.controles.Controls.Add(this.tabSubirArchivos);
            this.controles.Controls.Add(this.tabGestionUsuarios);
            this.controles.Controls.Add(this.tabPageEmpresas);
            this.controles.Cursor = System.Windows.Forms.Cursors.Hand;
            this.controles.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.controles.Location = new System.Drawing.Point(3, 50);
            this.controles.Name = "controles";
            this.controles.Padding = new System.Drawing.Point(20, 1);
            this.controles.SelectedIndex = 0;
            this.controles.Size = new System.Drawing.Size(1011, 608);
            this.controles.TabIndex = 5;
            // 
            // tabHome1
            // 
            this.tabHome1.BackColor = System.Drawing.Color.White;
            this.tabHome1.Controls.Add(this.btnMoverAfiles);
            this.tabHome1.Controls.Add(this.label17);
            this.tabHome1.Controls.Add(this.label15);
            this.tabHome1.Controls.Add(this.btnMoverAgestionEliminarEmpresa);
            this.tabHome1.Controls.Add(this.label13);
            this.tabHome1.Controls.Add(this.btnMoverAgestionCrearEmpresa);
            this.tabHome1.Controls.Add(this.lbUser1);
            this.tabHome1.Controls.Add(this.button2);
            this.tabHome1.Controls.Add(this.lbidkssss);
            this.tabHome1.Controls.Add(this.label11);
            this.tabHome1.Controls.Add(this.treeFiles);
            this.tabHome1.Location = new System.Drawing.Point(4, 27);
            this.tabHome1.Name = "tabHome1";
            this.tabHome1.Size = new System.Drawing.Size(1003, 577);
            this.tabHome1.TabIndex = 3;
            this.tabHome1.Text = "inicio";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(66, 129);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(98, 20);
            this.label15.TabIndex = 13;
            this.label15.Text = "Para empresa";
            // 
            // btnMoverAgestionEliminarEmpresa
            // 
            this.btnMoverAgestionEliminarEmpresa.Location = new System.Drawing.Point(104, 190);
            this.btnMoverAgestionEliminarEmpresa.Name = "btnMoverAgestionEliminarEmpresa";
            this.btnMoverAgestionEliminarEmpresa.Size = new System.Drawing.Size(133, 32);
            this.btnMoverAgestionEliminarEmpresa.TabIndex = 12;
            this.btnMoverAgestionEliminarEmpresa.Text = "Eliminar empresa";
            this.btnMoverAgestionEliminarEmpresa.UseVisualStyleBackColor = true;
            this.btnMoverAgestionEliminarEmpresa.Click += new System.EventHandler(this.btnMoverAgestionEliminarEmpresa_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Segoe UI Semibold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(21, 99);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(216, 30);
            this.label13.TabIndex = 11;
            this.label13.Text = "Opciones disponibles";
            // 
            // btnMoverAgestionCrearEmpresa
            // 
            this.btnMoverAgestionCrearEmpresa.Location = new System.Drawing.Point(104, 152);
            this.btnMoverAgestionCrearEmpresa.Name = "btnMoverAgestionCrearEmpresa";
            this.btnMoverAgestionCrearEmpresa.Size = new System.Drawing.Size(133, 32);
            this.btnMoverAgestionCrearEmpresa.TabIndex = 10;
            this.btnMoverAgestionCrearEmpresa.Text = "Crear empresa";
            this.btnMoverAgestionCrearEmpresa.UseVisualStyleBackColor = true;
            this.btnMoverAgestionCrearEmpresa.Click += new System.EventHandler(this.btnMoverAgestionCrearEmpresa_Click);
            // 
            // lbUser1
            // 
            this.lbUser1.AutoSize = true;
            this.lbUser1.BackColor = System.Drawing.Color.Transparent;
            this.lbUser1.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbUser1.ForeColor = System.Drawing.Color.Black;
            this.lbUser1.Location = new System.Drawing.Point(112, 24);
            this.lbUser1.Name = "lbUser1";
            this.lbUser1.Size = new System.Drawing.Size(0, 25);
            this.lbUser1.TabIndex = 4;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.button2.Location = new System.Drawing.Point(618, 51);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(88, 30);
            this.button2.TabIndex = 9;
            this.button2.Text = "actualizar";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // lbidkssss
            // 
            this.lbidkssss.AutoSize = true;
            this.lbidkssss.BackColor = System.Drawing.Color.Transparent;
            this.lbidkssss.Font = new System.Drawing.Font("Segoe UI Semibold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbidkssss.ForeColor = System.Drawing.Color.Black;
            this.lbidkssss.Location = new System.Drawing.Point(21, 19);
            this.lbidkssss.Name = "lbidkssss";
            this.lbidkssss.Size = new System.Drawing.Size(91, 30);
            this.lbidkssss.TabIndex = 3;
            this.lbidkssss.Text = "Usuario:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.White;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.label11.Location = new System.Drawing.Point(614, 19);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(138, 21);
            this.label11.TabIndex = 8;
            this.label11.Text = "Espacio de Trabajo";
            // 
            // treeFiles
            // 
            this.treeFiles.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.treeFiles.Location = new System.Drawing.Point(618, 99);
            this.treeFiles.Name = "treeFiles";
            this.treeFiles.Size = new System.Drawing.Size(374, 464);
            this.treeFiles.TabIndex = 7;
            this.treeFiles.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeFiles_AfterSelect);
            this.treeFiles.NodeMouseDoubleClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.treeFiles_NodeMouseDoubleClick);
            // 
            // tabSubirArchivos
            // 
            this.tabSubirArchivos.BackColor = System.Drawing.Color.White;
            this.tabSubirArchivos.Controls.Add(this.label16);
            this.tabSubirArchivos.Controls.Add(this.comboxEmpresasUploadFile);
            this.tabSubirArchivos.Controls.Add(this.btnUpdateUserFiles);
            this.tabSubirArchivos.Controls.Add(this.filesForUser);
            this.tabSubirArchivos.Controls.Add(this.btnSubir);
            this.tabSubirArchivos.Controls.Add(this.txtRuta);
            this.tabSubirArchivos.Controls.Add(this.btnSelect);
            this.tabSubirArchivos.Location = new System.Drawing.Point(4, 27);
            this.tabSubirArchivos.Name = "tabSubirArchivos";
            this.tabSubirArchivos.Size = new System.Drawing.Size(1003, 577);
            this.tabSubirArchivos.TabIndex = 2;
            this.tabSubirArchivos.Text = "Subir archivos";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(334, 498);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(69, 20);
            this.label16.TabIndex = 7;
            this.label16.Text = "Empresa:";
            // 
            // comboxEmpresasUploadFile
            // 
            this.comboxEmpresasUploadFile.FormattingEnabled = true;
            this.comboxEmpresasUploadFile.Location = new System.Drawing.Point(409, 494);
            this.comboxEmpresasUploadFile.Name = "comboxEmpresasUploadFile";
            this.comboxEmpresasUploadFile.Size = new System.Drawing.Size(248, 28);
            this.comboxEmpresasUploadFile.TabIndex = 6;
            // 
            // btnUpdateUserFiles
            // 
            this.btnUpdateUserFiles.Location = new System.Drawing.Point(849, 538);
            this.btnUpdateUserFiles.Name = "btnUpdateUserFiles";
            this.btnUpdateUserFiles.Size = new System.Drawing.Size(143, 34);
            this.btnUpdateUserFiles.TabIndex = 5;
            this.btnUpdateUserFiles.Text = "Actualizar";
            this.btnUpdateUserFiles.UseVisualStyleBackColor = true;
            this.btnUpdateUserFiles.Click += new System.EventHandler(this.btnUpdateUserFiles_Click);
            // 
            // filesForUser
            // 
            this.filesForUser.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.filesForUser.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.filesForUser.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.filesForUser.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            this.filesForUser.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.filesForUser.Location = new System.Drawing.Point(10, 12);
            this.filesForUser.Name = "filesForUser";
            this.filesForUser.ReadOnly = true;
            this.filesForUser.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            this.filesForUser.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.filesForUser.Size = new System.Drawing.Size(982, 477);
            this.filesForUser.TabIndex = 4;
            // 
            // btnSubir
            // 
            this.btnSubir.Location = new System.Drawing.Point(172, 538);
            this.btnSubir.Name = "btnSubir";
            this.btnSubir.Size = new System.Drawing.Size(136, 33);
            this.btnSubir.TabIndex = 3;
            this.btnSubir.Text = "subir archivo";
            this.btnSubir.UseVisualStyleBackColor = true;
            this.btnSubir.Visible = false;
            this.btnSubir.Click += new System.EventHandler(this.btnSubir_Click);
            // 
            // txtRuta
            // 
            this.txtRuta.Location = new System.Drawing.Point(10, 495);
            this.txtRuta.Name = "txtRuta";
            this.txtRuta.Size = new System.Drawing.Size(298, 27);
            this.txtRuta.TabIndex = 2;
            // 
            // btnSelect
            // 
            this.btnSelect.Location = new System.Drawing.Point(10, 537);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(143, 34);
            this.btnSelect.TabIndex = 1;
            this.btnSelect.Text = "seleccionar archivo";
            this.btnSelect.UseVisualStyleBackColor = true;
            this.btnSelect.Click += new System.EventHandler(this.button2_Click);
            // 
            // tabGestionUsuarios
            // 
            this.tabGestionUsuarios.BackColor = System.Drawing.Color.White;
            this.tabGestionUsuarios.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.tabGestionUsuarios.Controls.Add(this.panel3);
            this.tabGestionUsuarios.Controls.Add(this.tabControlToAdmin);
            this.tabGestionUsuarios.Location = new System.Drawing.Point(4, 27);
            this.tabGestionUsuarios.Name = "tabGestionUsuarios";
            this.tabGestionUsuarios.Padding = new System.Windows.Forms.Padding(3);
            this.tabGestionUsuarios.Size = new System.Drawing.Size(1003, 577);
            this.tabGestionUsuarios.TabIndex = 1;
            this.tabGestionUsuarios.Text = "Gestion Usuarios";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.allUsers);
            this.panel3.Controls.Add(this.btnUpdate);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(425, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(575, 571);
            this.panel3.TabIndex = 5;
            // 
            // allUsers
            // 
            this.allUsers.AllowUserToAddRows = false;
            this.allUsers.AllowUserToDeleteRows = false;
            this.allUsers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.allUsers.Location = new System.Drawing.Point(24, 43);
            this.allUsers.Name = "allUsers";
            this.allUsers.ReadOnly = true;
            this.allUsers.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.allUsers.Size = new System.Drawing.Size(531, 506);
            this.allUsers.TabIndex = 0;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(260, 7);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(92, 27);
            this.btnUpdate.TabIndex = 1;
            this.btnUpdate.Text = "Actualizar";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // tabControlToAdmin
            // 
            this.tabControlToAdmin.Controls.Add(this.tabHome);
            this.tabControlToAdmin.Controls.Add(this.tabCrearUsuario);
            this.tabControlToAdmin.Controls.Add(this.tabEditar);
            this.tabControlToAdmin.Controls.Add(this.tabEliminarUsuario);
            this.tabControlToAdmin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tabControlToAdmin.Dock = System.Windows.Forms.DockStyle.Left;
            this.tabControlToAdmin.Location = new System.Drawing.Point(3, 3);
            this.tabControlToAdmin.Name = "tabControlToAdmin";
            this.tabControlToAdmin.Padding = new System.Drawing.Point(20, 3);
            this.tabControlToAdmin.SelectedIndex = 0;
            this.tabControlToAdmin.Size = new System.Drawing.Size(422, 571);
            this.tabControlToAdmin.TabIndex = 4;
            // 
            // tabHome
            // 
            this.tabHome.BackColor = System.Drawing.Color.White;
            this.tabHome.Controls.Add(this.stateDb);
            this.tabHome.Controls.Add(this.label7);
            this.tabHome.Location = new System.Drawing.Point(4, 29);
            this.tabHome.Name = "tabHome";
            this.tabHome.Size = new System.Drawing.Size(414, 538);
            this.tabHome.TabIndex = 2;
            this.tabHome.Text = "Inicio";
            // 
            // stateDb
            // 
            this.stateDb.BackColor = System.Drawing.Color.LightGray;
            this.stateDb.Enabled = false;
            this.stateDb.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.stateDb.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stateDb.ForeColor = System.Drawing.Color.Black;
            this.stateDb.Location = new System.Drawing.Point(287, 27);
            this.stateDb.Name = "stateDb";
            this.stateDb.Size = new System.Drawing.Size(114, 30);
            this.stateDb.TabIndex = 5;
            this.stateDb.UseVisualStyleBackColor = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(26, 27);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 21);
            this.label7.TabIndex = 17;
            this.label7.Text = "bienvenido";
            // 
            // tabCrearUsuario
            // 
            this.tabCrearUsuario.BackColor = System.Drawing.Color.White;
            this.tabCrearUsuario.Controls.Add(this.comBoxAcceso);
            this.tabCrearUsuario.Controls.Add(this.label14);
            this.tabCrearUsuario.Controls.Add(this.label5);
            this.tabCrearUsuario.Controls.Add(this.comBoxPermisos);
            this.tabCrearUsuario.Controls.Add(this.label4);
            this.tabCrearUsuario.Controls.Add(this.txtUserPasswordToNewUser);
            this.tabCrearUsuario.Controls.Add(this.txtUserNameToNewUser);
            this.tabCrearUsuario.Controls.Add(this.btnCrearUsuario);
            this.tabCrearUsuario.Controls.Add(this.label3);
            this.tabCrearUsuario.Controls.Add(this.label2);
            this.tabCrearUsuario.ForeColor = System.Drawing.Color.White;
            this.tabCrearUsuario.Location = new System.Drawing.Point(4, 29);
            this.tabCrearUsuario.Name = "tabCrearUsuario";
            this.tabCrearUsuario.Padding = new System.Windows.Forms.Padding(3);
            this.tabCrearUsuario.Size = new System.Drawing.Size(414, 538);
            this.tabCrearUsuario.TabIndex = 0;
            this.tabCrearUsuario.Text = "Crear";
            // 
            // comBoxAcceso
            // 
            this.comBoxAcceso.BackColor = System.Drawing.Color.WhiteSmoke;
            this.comBoxAcceso.ForeColor = System.Drawing.SystemColors.ControlText;
            this.comBoxAcceso.FormattingEnabled = true;
            this.comBoxAcceso.Items.AddRange(new object[] {
            "Activado",
            "Denegado"});
            this.comBoxAcceso.Location = new System.Drawing.Point(119, 381);
            this.comBoxAcceso.Name = "comBoxAcceso";
            this.comBoxAcceso.Size = new System.Drawing.Size(185, 28);
            this.comBoxAcceso.TabIndex = 18;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label14.Location = new System.Drawing.Point(101, 357);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(60, 20);
            this.label14.TabIndex = 17;
            this.label14.Text = "Acceso:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(89, 127);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(231, 21);
            this.label5.TabIndex = 16;
            this.label5.Text = "Ingrese datos del nuevo usuario";
            // 
            // comBoxPermisos
            // 
            this.comBoxPermisos.BackColor = System.Drawing.Color.WhiteSmoke;
            this.comBoxPermisos.ForeColor = System.Drawing.SystemColors.ControlText;
            this.comBoxPermisos.FormattingEnabled = true;
            this.comBoxPermisos.Items.AddRange(new object[] {
            "Administrador",
            "Usuario"});
            this.comBoxPermisos.Location = new System.Drawing.Point(119, 314);
            this.comBoxPermisos.Name = "comBoxPermisos";
            this.comBoxPermisos.Size = new System.Drawing.Size(185, 28);
            this.comBoxPermisos.TabIndex = 15;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.Location = new System.Drawing.Point(101, 290);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 20);
            this.label4.TabIndex = 14;
            this.label4.Text = "Permisos:";
            // 
            // txtUserPasswordToNewUser
            // 
            this.txtUserPasswordToNewUser.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtUserPasswordToNewUser.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtUserPasswordToNewUser.Location = new System.Drawing.Point(119, 250);
            this.txtUserPasswordToNewUser.Name = "txtUserPasswordToNewUser";
            this.txtUserPasswordToNewUser.Size = new System.Drawing.Size(185, 27);
            this.txtUserPasswordToNewUser.TabIndex = 13;
            // 
            // txtUserNameToNewUser
            // 
            this.txtUserNameToNewUser.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtUserNameToNewUser.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtUserNameToNewUser.Location = new System.Drawing.Point(119, 188);
            this.txtUserNameToNewUser.Name = "txtUserNameToNewUser";
            this.txtUserNameToNewUser.Size = new System.Drawing.Size(185, 27);
            this.txtUserNameToNewUser.TabIndex = 12;
            // 
            // btnCrearUsuario
            // 
            this.btnCrearUsuario.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnCrearUsuario.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnCrearUsuario.Location = new System.Drawing.Point(157, 438);
            this.btnCrearUsuario.Name = "btnCrearUsuario";
            this.btnCrearUsuario.Size = new System.Drawing.Size(109, 27);
            this.btnCrearUsuario.TabIndex = 11;
            this.btnCrearUsuario.Text = "Crear Usuario";
            this.btnCrearUsuario.UseVisualStyleBackColor = false;
            this.btnCrearUsuario.Click += new System.EventHandler(this.btnCrearUsuario_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Location = new System.Drawing.Point(101, 164);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(157, 21);
            this.label3.TabIndex = 10;
            this.label3.Text = "Nombre de Usuario:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Location = new System.Drawing.Point(101, 226);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 20);
            this.label2.TabIndex = 9;
            this.label2.Text = "Contraseña:";
            // 
            // tabEditar
            // 
            this.tabEditar.BackColor = System.Drawing.Color.White;
            this.tabEditar.Controls.Add(this.btnEditarCancelar);
            this.tabEditar.Controls.Add(this.comBoxEditarAcceso);
            this.tabEditar.Controls.Add(this.lbForEditarAcceso);
            this.tabEditar.Controls.Add(this.lbForEdit);
            this.tabEditar.Controls.Add(this.btnBuscarUsuario);
            this.tabEditar.Controls.Add(this.txtForMessageEditar);
            this.tabEditar.Controls.Add(this.comBoxEditarPermisos);
            this.tabEditar.Controls.Add(this.lbForEditarPermisos);
            this.tabEditar.Controls.Add(this.txtEditPassword);
            this.tabEditar.Controls.Add(this.txtEditName);
            this.tabEditar.Controls.Add(this.btnGuardarCambios);
            this.tabEditar.Controls.Add(this.lbForEditarName);
            this.tabEditar.Controls.Add(this.lbForEditarPassword);
            this.tabEditar.Controls.Add(this.label8);
            this.tabEditar.Controls.Add(this.txtIdEditar);
            this.tabEditar.Controls.Add(this.label9);
            this.tabEditar.Location = new System.Drawing.Point(4, 29);
            this.tabEditar.Name = "tabEditar";
            this.tabEditar.Padding = new System.Windows.Forms.Padding(3);
            this.tabEditar.Size = new System.Drawing.Size(414, 538);
            this.tabEditar.TabIndex = 3;
            this.tabEditar.Text = "Editar";
            // 
            // btnEditarCancelar
            // 
            this.btnEditarCancelar.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnEditarCancelar.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnEditarCancelar.Location = new System.Drawing.Point(222, 493);
            this.btnEditarCancelar.Name = "btnEditarCancelar";
            this.btnEditarCancelar.Size = new System.Drawing.Size(128, 27);
            this.btnEditarCancelar.TabIndex = 33;
            this.btnEditarCancelar.Text = "Cancelar";
            this.btnEditarCancelar.UseVisualStyleBackColor = false;
            this.btnEditarCancelar.Visible = false;
            this.btnEditarCancelar.Click += new System.EventHandler(this.btnEditarCancelar_Click);
            // 
            // comBoxEditarAcceso
            // 
            this.comBoxEditarAcceso.BackColor = System.Drawing.Color.WhiteSmoke;
            this.comBoxEditarAcceso.ForeColor = System.Drawing.SystemColors.ControlText;
            this.comBoxEditarAcceso.FormattingEnabled = true;
            this.comBoxEditarAcceso.Items.AddRange(new object[] {
            "Activado",
            "Denegado"});
            this.comBoxEditarAcceso.Location = new System.Drawing.Point(122, 392);
            this.comBoxEditarAcceso.Name = "comBoxEditarAcceso";
            this.comBoxEditarAcceso.Size = new System.Drawing.Size(185, 28);
            this.comBoxEditarAcceso.TabIndex = 32;
            this.comBoxEditarAcceso.Visible = false;
            // 
            // lbForEditarAcceso
            // 
            this.lbForEditarAcceso.AutoSize = true;
            this.lbForEditarAcceso.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbForEditarAcceso.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbForEditarAcceso.Location = new System.Drawing.Point(108, 368);
            this.lbForEditarAcceso.Name = "lbForEditarAcceso";
            this.lbForEditarAcceso.Size = new System.Drawing.Size(60, 20);
            this.lbForEditarAcceso.TabIndex = 31;
            this.lbForEditarAcceso.Text = "Acceso:";
            this.lbForEditarAcceso.Visible = false;
            // 
            // lbForEdit
            // 
            this.lbForEdit.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbForEdit.ForeColor = System.Drawing.Color.Black;
            this.lbForEdit.Location = new System.Drawing.Point(10, 442);
            this.lbForEdit.Name = "lbForEdit";
            this.lbForEdit.Size = new System.Drawing.Size(396, 30);
            this.lbForEdit.TabIndex = 30;
            this.lbForEdit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnBuscarUsuario
            // 
            this.btnBuscarUsuario.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnBuscarUsuario.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnBuscarUsuario.Location = new System.Drawing.Point(137, 116);
            this.btnBuscarUsuario.Name = "btnBuscarUsuario";
            this.btnBuscarUsuario.Size = new System.Drawing.Size(128, 27);
            this.btnBuscarUsuario.TabIndex = 29;
            this.btnBuscarUsuario.Text = "buscar usuario";
            this.btnBuscarUsuario.UseVisualStyleBackColor = false;
            this.btnBuscarUsuario.Click += new System.EventHandler(this.btnBuscarUsuario_Click);
            // 
            // txtForMessageEditar
            // 
            this.txtForMessageEditar.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtForMessageEditar.ForeColor = System.Drawing.Color.Black;
            this.txtForMessageEditar.Location = new System.Drawing.Point(10, 150);
            this.txtForMessageEditar.Name = "txtForMessageEditar";
            this.txtForMessageEditar.Size = new System.Drawing.Size(396, 28);
            this.txtForMessageEditar.TabIndex = 28;
            this.txtForMessageEditar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // comBoxEditarPermisos
            // 
            this.comBoxEditarPermisos.BackColor = System.Drawing.Color.WhiteSmoke;
            this.comBoxEditarPermisos.ForeColor = System.Drawing.SystemColors.ControlText;
            this.comBoxEditarPermisos.FormattingEnabled = true;
            this.comBoxEditarPermisos.Items.AddRange(new object[] {
            "Administrador",
            "Usuario"});
            this.comBoxEditarPermisos.Location = new System.Drawing.Point(122, 328);
            this.comBoxEditarPermisos.Name = "comBoxEditarPermisos";
            this.comBoxEditarPermisos.Size = new System.Drawing.Size(185, 28);
            this.comBoxEditarPermisos.TabIndex = 27;
            this.comBoxEditarPermisos.Visible = false;
            // 
            // lbForEditarPermisos
            // 
            this.lbForEditarPermisos.AutoSize = true;
            this.lbForEditarPermisos.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbForEditarPermisos.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbForEditarPermisos.Location = new System.Drawing.Point(108, 304);
            this.lbForEditarPermisos.Name = "lbForEditarPermisos";
            this.lbForEditarPermisos.Size = new System.Drawing.Size(73, 20);
            this.lbForEditarPermisos.TabIndex = 26;
            this.lbForEditarPermisos.Text = "Permisos:";
            this.lbForEditarPermisos.Visible = false;
            // 
            // txtEditPassword
            // 
            this.txtEditPassword.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtEditPassword.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtEditPassword.Location = new System.Drawing.Point(122, 264);
            this.txtEditPassword.Name = "txtEditPassword";
            this.txtEditPassword.Size = new System.Drawing.Size(185, 27);
            this.txtEditPassword.TabIndex = 25;
            this.txtEditPassword.Visible = false;
            // 
            // txtEditName
            // 
            this.txtEditName.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtEditName.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtEditName.Location = new System.Drawing.Point(122, 202);
            this.txtEditName.Name = "txtEditName";
            this.txtEditName.Size = new System.Drawing.Size(185, 27);
            this.txtEditName.TabIndex = 24;
            this.txtEditName.Visible = false;
            // 
            // btnGuardarCambios
            // 
            this.btnGuardarCambios.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnGuardarCambios.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnGuardarCambios.Location = new System.Drawing.Point(67, 493);
            this.btnGuardarCambios.Name = "btnGuardarCambios";
            this.btnGuardarCambios.Size = new System.Drawing.Size(131, 27);
            this.btnGuardarCambios.TabIndex = 23;
            this.btnGuardarCambios.Text = "Guardar cambios";
            this.btnGuardarCambios.UseVisualStyleBackColor = false;
            this.btnGuardarCambios.Visible = false;
            this.btnGuardarCambios.Click += new System.EventHandler(this.btnGuardarCambios_Click);
            // 
            // lbForEditarName
            // 
            this.lbForEditarName.AutoSize = true;
            this.lbForEditarName.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbForEditarName.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbForEditarName.Location = new System.Drawing.Point(108, 178);
            this.lbForEditarName.Name = "lbForEditarName";
            this.lbForEditarName.Size = new System.Drawing.Size(157, 21);
            this.lbForEditarName.TabIndex = 22;
            this.lbForEditarName.Text = "Nombre de Usuario:";
            this.lbForEditarName.Visible = false;
            // 
            // lbForEditarPassword
            // 
            this.lbForEditarPassword.AutoSize = true;
            this.lbForEditarPassword.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbForEditarPassword.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbForEditarPassword.Location = new System.Drawing.Point(108, 240);
            this.lbForEditarPassword.Name = "lbForEditarPassword";
            this.lbForEditarPassword.Size = new System.Drawing.Size(90, 20);
            this.lbForEditarPassword.TabIndex = 21;
            this.lbForEditarPassword.Text = "Contraseña:";
            this.lbForEditarPassword.Visible = false;
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(6, 10);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(261, 27);
            this.label8.TabIndex = 20;
            this.label8.Text = "Ingrese datos del usuario a editar";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtIdEditar
            // 
            this.txtIdEditar.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtIdEditar.Location = new System.Drawing.Point(111, 77);
            this.txtIdEditar.Name = "txtIdEditar";
            this.txtIdEditar.Size = new System.Drawing.Size(181, 27);
            this.txtIdEditar.TabIndex = 19;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(100, 43);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(63, 21);
            this.label9.TabIndex = 18;
            this.label9.Text = "User ID";
            // 
            // tabEliminarUsuario
            // 
            this.tabEliminarUsuario.BackColor = System.Drawing.Color.White;
            this.tabEliminarUsuario.Controls.Add(this.label6);
            this.tabEliminarUsuario.Controls.Add(this.btnEliminarUser);
            this.tabEliminarUsuario.Controls.Add(this.txtUserId);
            this.tabEliminarUsuario.Controls.Add(this.label1);
            this.tabEliminarUsuario.Location = new System.Drawing.Point(4, 29);
            this.tabEliminarUsuario.Name = "tabEliminarUsuario";
            this.tabEliminarUsuario.Padding = new System.Windows.Forms.Padding(3);
            this.tabEliminarUsuario.Size = new System.Drawing.Size(414, 538);
            this.tabEliminarUsuario.TabIndex = 1;
            this.tabEliminarUsuario.Text = "Eliminar";
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(95, 138);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(229, 43);
            this.label6.TabIndex = 17;
            this.label6.Text = "Ingrese datos del usuario a eliminar";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnEliminarUser
            // 
            this.btnEliminarUser.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEliminarUser.Location = new System.Drawing.Point(169, 416);
            this.btnEliminarUser.Name = "btnEliminarUser";
            this.btnEliminarUser.Size = new System.Drawing.Size(81, 32);
            this.btnEliminarUser.TabIndex = 11;
            this.btnEliminarUser.Text = "Eliminar";
            this.btnEliminarUser.UseVisualStyleBackColor = true;
            this.btnEliminarUser.Click += new System.EventHandler(this.btnEliminarUser_Click);
            // 
            // txtUserId
            // 
            this.txtUserId.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtUserId.Location = new System.Drawing.Point(119, 234);
            this.txtUserId.Name = "txtUserId";
            this.txtUserId.Size = new System.Drawing.Size(181, 27);
            this.txtUserId.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(115, 210);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 21);
            this.label1.TabIndex = 9;
            this.label1.Text = "User ID";
            // 
            // tabPageEmpresas
            // 
            this.tabPageEmpresas.BackColor = System.Drawing.Color.White;
            this.tabPageEmpresas.Controls.Add(this.tabControlToGestionDeEmpresas);
            this.tabPageEmpresas.Controls.Add(this.btnActualizarEmpresas);
            this.tabPageEmpresas.Controls.Add(this.dataGridViewforAllEmpresas);
            this.tabPageEmpresas.Location = new System.Drawing.Point(4, 27);
            this.tabPageEmpresas.Name = "tabPageEmpresas";
            this.tabPageEmpresas.Size = new System.Drawing.Size(1003, 577);
            this.tabPageEmpresas.TabIndex = 4;
            this.tabPageEmpresas.Text = "Gestion Empresas";
            // 
            // tabControlToGestionDeEmpresas
            // 
            this.tabControlToGestionDeEmpresas.Controls.Add(this.tabcrearEmpresa);
            this.tabControlToGestionDeEmpresas.Controls.Add(this.tabeliminarEmpresa);
            this.tabControlToGestionDeEmpresas.Location = new System.Drawing.Point(19, 17);
            this.tabControlToGestionDeEmpresas.Name = "tabControlToGestionDeEmpresas";
            this.tabControlToGestionDeEmpresas.SelectedIndex = 0;
            this.tabControlToGestionDeEmpresas.Size = new System.Drawing.Size(421, 542);
            this.tabControlToGestionDeEmpresas.TabIndex = 10;
            // 
            // tabcrearEmpresa
            // 
            this.tabcrearEmpresa.BackColor = System.Drawing.Color.White;
            this.tabcrearEmpresa.Controls.Add(this.btnCrearEmpresa);
            this.tabcrearEmpresa.Controls.Add(this.label10);
            this.tabcrearEmpresa.Controls.Add(this.txtCrearEmpresa);
            this.tabcrearEmpresa.Location = new System.Drawing.Point(4, 29);
            this.tabcrearEmpresa.Name = "tabcrearEmpresa";
            this.tabcrearEmpresa.Padding = new System.Windows.Forms.Padding(3);
            this.tabcrearEmpresa.Size = new System.Drawing.Size(413, 509);
            this.tabcrearEmpresa.TabIndex = 1;
            this.tabcrearEmpresa.Text = "Crear Empresa";
            // 
            // btnCrearEmpresa
            // 
            this.btnCrearEmpresa.Location = new System.Drawing.Point(238, 461);
            this.btnCrearEmpresa.Name = "btnCrearEmpresa";
            this.btnCrearEmpresa.Size = new System.Drawing.Size(157, 28);
            this.btnCrearEmpresa.TabIndex = 2;
            this.btnCrearEmpresa.Text = "Crear Empresa";
            this.btnCrearEmpresa.UseVisualStyleBackColor = true;
            this.btnCrearEmpresa.Click += new System.EventHandler(this.btnCrearEmpresa_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(78, 109);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(66, 20);
            this.label10.TabIndex = 1;
            this.label10.Text = "Empresa";
            // 
            // txtCrearEmpresa
            // 
            this.txtCrearEmpresa.Location = new System.Drawing.Point(166, 109);
            this.txtCrearEmpresa.Name = "txtCrearEmpresa";
            this.txtCrearEmpresa.Size = new System.Drawing.Size(179, 27);
            this.txtCrearEmpresa.TabIndex = 0;
            // 
            // tabeliminarEmpresa
            // 
            this.tabeliminarEmpresa.BackColor = System.Drawing.Color.White;
            this.tabeliminarEmpresa.Controls.Add(this.btnEliminarEmpresa);
            this.tabeliminarEmpresa.Controls.Add(this.label12);
            this.tabeliminarEmpresa.Controls.Add(this.txtEliminarEmpresa);
            this.tabeliminarEmpresa.Location = new System.Drawing.Point(4, 29);
            this.tabeliminarEmpresa.Name = "tabeliminarEmpresa";
            this.tabeliminarEmpresa.Size = new System.Drawing.Size(413, 509);
            this.tabeliminarEmpresa.TabIndex = 2;
            this.tabeliminarEmpresa.Text = "Eliminar Empresa";
            // 
            // btnEliminarEmpresa
            // 
            this.btnEliminarEmpresa.Location = new System.Drawing.Point(237, 459);
            this.btnEliminarEmpresa.Name = "btnEliminarEmpresa";
            this.btnEliminarEmpresa.Size = new System.Drawing.Size(157, 28);
            this.btnEliminarEmpresa.TabIndex = 5;
            this.btnEliminarEmpresa.Text = "Eliminar Empresa";
            this.btnEliminarEmpresa.UseVisualStyleBackColor = true;
            this.btnEliminarEmpresa.Click += new System.EventHandler(this.btnEliminarEmpresa_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(67, 118);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(66, 20);
            this.label12.TabIndex = 4;
            this.label12.Text = "Empresa";
            // 
            // txtEliminarEmpresa
            // 
            this.txtEliminarEmpresa.Location = new System.Drawing.Point(155, 118);
            this.txtEliminarEmpresa.Name = "txtEliminarEmpresa";
            this.txtEliminarEmpresa.Size = new System.Drawing.Size(148, 27);
            this.txtEliminarEmpresa.TabIndex = 3;
            // 
            // btnActualizarEmpresas
            // 
            this.btnActualizarEmpresas.Location = new System.Drawing.Point(461, 17);
            this.btnActualizarEmpresas.Name = "btnActualizarEmpresas";
            this.btnActualizarEmpresas.Size = new System.Drawing.Size(128, 27);
            this.btnActualizarEmpresas.TabIndex = 1;
            this.btnActualizarEmpresas.Text = "Actualizar";
            this.btnActualizarEmpresas.UseVisualStyleBackColor = true;
            this.btnActualizarEmpresas.Click += new System.EventHandler(this.btnActualizarEmpresas_Click);
            // 
            // dataGridViewforAllEmpresas
            // 
            this.dataGridViewforAllEmpresas.AllowUserToAddRows = false;
            this.dataGridViewforAllEmpresas.AllowUserToDeleteRows = false;
            this.dataGridViewforAllEmpresas.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewforAllEmpresas.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridViewforAllEmpresas.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridViewforAllEmpresas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewforAllEmpresas.Location = new System.Drawing.Point(461, 50);
            this.dataGridViewforAllEmpresas.Name = "dataGridViewforAllEmpresas";
            this.dataGridViewforAllEmpresas.ReadOnly = true;
            this.dataGridViewforAllEmpresas.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dataGridViewforAllEmpresas.Size = new System.Drawing.Size(531, 522);
            this.dataGridViewforAllEmpresas.TabIndex = 0;
            // 
            // btnCerrarSesion
            // 
            this.btnCerrarSesion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(24)))), ((int)(((byte)(68)))));
            this.btnCerrarSesion.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCerrarSesion.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCerrarSesion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.btnCerrarSesion.Location = new System.Drawing.Point(816, 7);
            this.btnCerrarSesion.Name = "btnCerrarSesion";
            this.btnCerrarSesion.Size = new System.Drawing.Size(115, 30);
            this.btnCerrarSesion.TabIndex = 1;
            this.btnCerrarSesion.Text = "Cerrar Sesion ";
            this.btnCerrarSesion.UseVisualStyleBackColor = false;
            this.btnCerrarSesion.Click += new System.EventHandler(this.btnCerrarSesion_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(24)))), ((int)(((byte)(68)))));
            this.panel2.Controls.Add(this.btnSalir);
            this.panel2.Controls.Add(this.btnCerrarSesion);
            this.panel2.ForeColor = System.Drawing.Color.Transparent;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1014, 44);
            this.panel2.TabIndex = 10;
            // 
            // btnSalir
            // 
            this.btnSalir.BackColor = System.Drawing.Color.Black;
            this.btnSalir.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSalir.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSalir.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalir.ForeColor = System.Drawing.Color.Transparent;
            this.btnSalir.Location = new System.Drawing.Point(937, 8);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(62, 29);
            this.btnSalir.TabIndex = 0;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = false;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // panel1
            // 
            this.panel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.controles);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1014, 661);
            this.panel1.TabIndex = 6;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(66, 303);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(95, 20);
            this.label17.TabIndex = 14;
            this.label17.Text = "Para archivos";
            // 
            // btnMoverAfiles
            // 
            this.btnMoverAfiles.Location = new System.Drawing.Point(104, 326);
            this.btnMoverAfiles.Name = "btnMoverAfiles";
            this.btnMoverAfiles.Size = new System.Drawing.Size(133, 32);
            this.btnMoverAfiles.TabIndex = 15;
            this.btnMoverAfiles.Text = "subir archivos";
            this.btnMoverAfiles.UseVisualStyleBackColor = true;
            this.btnMoverAfiles.Click += new System.EventHandler(this.btnMoverAfiles_Click);
            // 
            // main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1014, 661);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.IsMdiContainer = true;
            this.MaximizeBox = false;
            this.Name = "main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "main";
            this.Load += new System.EventHandler(this.main_Load);
            this.controles.ResumeLayout(false);
            this.tabHome1.ResumeLayout(false);
            this.tabHome1.PerformLayout();
            this.tabSubirArchivos.ResumeLayout(false);
            this.tabSubirArchivos.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.filesForUser)).EndInit();
            this.tabGestionUsuarios.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.allUsers)).EndInit();
            this.tabControlToAdmin.ResumeLayout(false);
            this.tabHome.ResumeLayout(false);
            this.tabHome.PerformLayout();
            this.tabCrearUsuario.ResumeLayout(false);
            this.tabCrearUsuario.PerformLayout();
            this.tabEditar.ResumeLayout(false);
            this.tabEditar.PerformLayout();
            this.tabEliminarUsuario.ResumeLayout(false);
            this.tabEliminarUsuario.PerformLayout();
            this.tabPageEmpresas.ResumeLayout(false);
            this.tabControlToGestionDeEmpresas.ResumeLayout(false);
            this.tabcrearEmpresa.ResumeLayout(false);
            this.tabcrearEmpresa.PerformLayout();
            this.tabeliminarEmpresa.ResumeLayout(false);
            this.tabeliminarEmpresa.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewforAllEmpresas)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl controles;
        private System.Windows.Forms.TabPage tabHome1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TreeView treeFiles;
        private System.Windows.Forms.TabPage tabSubirArchivos;
        private System.Windows.Forms.Button btnUpdateUserFiles;
        private System.Windows.Forms.DataGridView filesForUser;
        private System.Windows.Forms.Button btnSubir;
        private System.Windows.Forms.TextBox txtRuta;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.TabPage tabGestionUsuarios;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridView allUsers;
        private System.Windows.Forms.TabControl tabControlToAdmin;
        private System.Windows.Forms.TabPage tabHome;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TabPage tabCrearUsuario;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comBoxPermisos;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtUserPasswordToNewUser;
        private System.Windows.Forms.TextBox txtUserNameToNewUser;
        private System.Windows.Forms.Button btnCrearUsuario;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabPage tabEditar;
        private System.Windows.Forms.Label lbForEdit;
        private System.Windows.Forms.Button btnBuscarUsuario;
        private System.Windows.Forms.Label txtForMessageEditar;
        private System.Windows.Forms.ComboBox comBoxEditarPermisos;
        private System.Windows.Forms.Label lbForEditarPermisos;
        private System.Windows.Forms.TextBox txtEditPassword;
        private System.Windows.Forms.TextBox txtEditName;
        private System.Windows.Forms.Button btnGuardarCambios;
        private System.Windows.Forms.Label lbForEditarName;
        private System.Windows.Forms.Label lbForEditarPassword;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtIdEditar;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TabPage tabEliminarUsuario;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnEliminarUser;
        private System.Windows.Forms.TextBox txtUserId;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button stateDb;
        private System.Windows.Forms.Button btnCerrarSesion;
        private System.Windows.Forms.Label lbUser1;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Label lbidkssss;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox comBoxAcceso;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox comBoxEditarAcceso;
        private System.Windows.Forms.Label lbForEditarAcceso;
        private System.Windows.Forms.Button btnEditarCancelar;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.TabControl tabControlToGestionDeEmpresas;
        private System.Windows.Forms.TabPage tabcrearEmpresa;
        private System.Windows.Forms.Button btnCrearEmpresa;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtCrearEmpresa;
        private System.Windows.Forms.TabPage tabPageEmpresas;
        private System.Windows.Forms.TabPage tabeliminarEmpresa;
        private System.Windows.Forms.Button btnActualizarEmpresas;
        private System.Windows.Forms.DataGridView dataGridViewforAllEmpresas;
        private System.Windows.Forms.Button btnEliminarEmpresa;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtEliminarEmpresa;
        private System.Windows.Forms.Button btnMoverAgestionEliminarEmpresa;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnMoverAgestionCrearEmpresa;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox comboxEmpresasUploadFile;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button btnMoverAfiles;
        private System.Windows.Forms.Label label17;
    }
}

