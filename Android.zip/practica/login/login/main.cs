﻿using logica;
using System;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

namespace login
{
    public partial class main : Form
    {
        l_User l_User = new l_User();
        l_main l_main = new l_main();
        l_files l_files = new l_files();
        loginForm login = new loginForm();
        l_empresa l_Empresa = new l_empresa();

        int idEditUser;

        public main()
        {
            InitializeComponent();
        }



        public void forAdmin()
        {
            allUsers.DataSource = l_User.ls_users();
            lbUser1.Text = l_User.GetUserName();
            //config
            comBoxPermisos.SelectedIndex = 1;
            comBoxAcceso.SelectedIndex = 0;
            // para eliminar los tabs y solo dejar gestion de usuario
            // para eliminar los tabs y solo dejar gestion de usuario
            controles.TabPages.Remove(tabSubirArchivos);
            controles.TabPages.Remove(tabHome1);
            controles.TabPages.Remove(tabPageEmpresas);
        }

        private void forUser()
        {
            controles.TabPages.Remove(tabGestionUsuarios);
            filesForUser.DataSource = l_files.ls_files(l_User.GetUserId());
            //dataGridViewforAllEmpresas.DataSource = l_Empresa.ls_files(l_User.GetUserId());
            //nose no se establece la ruta
            listadoEmpresas();
            lbUser1.Text = l_User.GetUserName();
            //treeFiles.Nodes.Clear();
            LlenarTreeView(l_User.getuser, treeFiles.Nodes);
        }

        private void listadoEmpresas()
        {
            
            LlenarComboBoxConCarpetas(Path.GetFullPath(l_main.getUserPath()));
        }

        private void LlenarComboBoxConCarpetas(string rutaDirectorio)
        {
            // Verifica si el directorio existe
            if (Directory.Exists(rutaDirectorio))
            {
                // Obtiene los nombres de las carpetas en el directorio
                string[] carpetas = Directory.GetDirectories(rutaDirectorio);

                // Limpia el ComboBox antes de agregar nuevos elementos
                comboxEmpresasUploadFile.Items.Clear();

                // Agrega los nombres de las carpetas al ComboBox
                foreach (string carpeta in carpetas)
                {
                    string nombreCarpeta = Path.GetFileName(carpeta);
                    comboxEmpresasUploadFile.Items.Add(nombreCarpeta);
                }
            }
            else
            {
                MessageBox.Show("El directorio no existe.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void main_Load(object sender, EventArgs e)
        {

            if (login.ShowDialog() != DialogResult.OK)
            {
                Application.Exit();
            }

            //this.saludo();
            this.load();
        }

        /// <summary>
        /// Cuando carga el aplicativo verificara si es administrador o usuario
        /// </summary>
        private void load()
        {
            l_main.loadConfi();

            if (l_User.GetUserPermissions() == 1)
            {
                forAdmin();
            }
            else
            {
                forUser();
            }
        }


        //for gestion de usuarios
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            allUsers.DataSource = l_User.ls_users();
        }
        //-------------------------------------

        // Crea el usuario
        private void btnCrearUsuario_Click(object sender, EventArgs e)
        {
            string userName = txtUserNameToNewUser.Text;
            string userPassword = txtUserPasswordToNewUser.Text;
            string userPermisosTxt = comBoxPermisos.Text;
            string userAccesoTxt = comBoxAcceso.Text;
            int userPermisos = 0;
            int acceso = 0;



            if (!string.IsNullOrEmpty(userName) && !string.IsNullOrEmpty(userPassword) && !string.IsNullOrEmpty(userPermisosTxt) && !string.IsNullOrEmpty(userAccesoTxt)
                && !string.IsNullOrWhiteSpace(userName) && !string.IsNullOrWhiteSpace(userPassword)
                )
            {
                if (userPermisosTxt == "Administrador")
                {
                    userPermisos = 1;
                }

                if (userAccesoTxt == "Denegado")
                {
                    acceso = 1;
                }

                if (userName.Contains(" ") || userPassword.Contains(" "))
                {
                    MessageBox.Show("Los campos no deben contener espacios en blanco.", "Espacios en blanco", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    if (l_User.createUser(userName, userPassword, userPermisos, acceso))
                    {
                        MessageBox.Show("El Usuario " + userName + " Sido creado");
                        txtUserNameToNewUser.Text = "";
                        txtUserPasswordToNewUser.Text = "";
                        comBoxPermisos.SelectedIndex = 1;
                        comBoxAcceso.SelectedIndex = 0;
                        txtUserNameToNewUser.Focus();
                    }
                    else
                    {
                        MessageBox.Show("El Usuario Ya Existe");
                    }
                }
            }
            else
            {
                MessageBox.Show("Algun valor vacio");
            }
        }
        //-------------------------------------

        //busacar el usuario a editar
        private void btnBuscarUsuario_Click(object sender, EventArgs e)
        {

            if (int.TryParse(txtIdEditar.Text, out idEditUser))
            {
                DataTable userInfo = l_User.getUserInfobyId(idEditUser);
                if (l_User.getUserInfobyId(idEditUser).Rows.Count > 0)
                {
                    txtForMessageEditar.Text = "Usuario encontrado";
                    editForm(true);
                    foreach (DataRow row in userInfo.Rows)
                    {
                        txtEditName.Text = row["UserName"].ToString();
                        txtEditPassword.Text = row["UserPassword"].ToString();
                        if (Convert.ToInt32(row["UserPermissions"]) == 0)
                        {
                            comBoxEditarPermisos.SelectedIndex = 1;
                        }
                        else
                        {
                            comBoxEditarPermisos.SelectedIndex = 0;
                        }
                        //Activado 1 
                        //Denegado 0
                        if (Convert.ToInt32(row["UserAcceso"]) == 1)
                        {
                            comBoxEditarAcceso.SelectedIndex = 1;
                        }
                        else
                        {
                            comBoxEditarAcceso.SelectedIndex = 0;
                        }
                    }
                }
                else
                {
                    txtForMessageEditar.Text = "Usuario no encontrado";

                    editForm(false);

                }
            }
            else
            {
                txtForMessageEditar.Text = "Ingrese un valor valido";
                editForm(false);
            }
        }
        //-------------------------------------

        // guarda los cambios de l usuario editado
        private void btnGuardarCambios_Click(object sender, EventArgs e)
        {
            string newName = txtEditName.Text;
            string newPassword = txtEditPassword.Text;
            int newPermiso = 0;
            int newAcceso = 0;

            if (!string.IsNullOrEmpty(txtEditName.Text) && !string.IsNullOrEmpty(txtEditPassword.Text) && !string.IsNullOrEmpty(comBoxEditarPermisos.Text))
            {
                // Para permisos
                if (comBoxEditarPermisos.Text == "Administrador")
                {
                    newPermiso = 1;
                }
                // Para acceso
                if (comBoxEditarAcceso.Text == "Denegado")
                {
                    newAcceso = 1;
                }

                if (newName.Contains(" ") || newPassword.Contains(" "))
                {
                    MessageBox.Show("Los campos no deben contener espacios en blanco.", "Espacios en blanco", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    if (l_User.updateUser(idEditUser, newName, newPassword, newPermiso, newAcceso))
                    {
                        MessageBox.Show("Usuario actualizado");

                        txtForMessageEditar.Text = "";
                        editForm(false);
                    }
                    else
                    {
                        MessageBox.Show("Error al actualizar usuario");
                    }
                }

            }
            else
            {
                lbForEdit.Text = "Algun valor vacio";
            }
        }
        //-------------------------------------

        // Para cancelar la edicion
        private void btnEditarCancelar_Click(object sender, EventArgs e)
        {
            txtForMessageEditar.Text = "";
            editForm(false);
        }
        //-------------------------------------

        // Para eliminar
        private void btnEliminarUser_Click(object sender, EventArgs e)
        {
            int UserId;
            if (int.TryParse(txtUserId.Text, out UserId))
            {
                if (l_User.deleteUser(UserId))
                {
                    MessageBox.Show("Se elimino usuario correctamente");
                    txtUserId.Text = "";
                    txtUserId.Focus();
                }
                else
                {
                    MessageBox.Show("No se pudo eliminar el usuario verifica si el usuario existe");
                }
            }
            else
            {
                MessageBox.Show("Ingrese un valor correcto");
            }
        }
        //-------------------------------------

        // para salir y cerrar sesion
        private void btnCerrarSesion_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }
        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        //-------------------------------------


        /* 
        General porque se le llama varias veces
        es para llamar al formulario de editar o ocultarlo
         */
        private void editForm(bool action)
        {
            //label
            lbForEditarName.Visible = action;
            lbForEditarPassword.Visible = action;
            lbForEditarPermisos.Visible = action;
            lbForEditarAcceso.Visible = action;
            //textbox
            txtEditName.Visible = action;
            txtEditPassword.Visible = action;
            comBoxEditarPermisos.Visible = action;
            comBoxEditarAcceso.Visible = action;
            //butons
            btnGuardarCambios.Visible = action;
            btnEditarCancelar.Visible = action;
        }


        // para selecionar el archivo
        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Title = "Seleccionar archivo";
            openFileDialog.Filter = "Archivos de texto|*.xlsx|Todos los archivos|*.*";

            DialogResult result = openFileDialog.ShowDialog();

            if (result == DialogResult.OK)
            {
                string rutaArchivo = openFileDialog.FileName;
                txtRuta.Text = rutaArchivo;
                btnSubir.Visible = true;
            }
        }

        // para subir archivos
        private void btnSubir_Click(object sender, EventArgs e)
        {
            string ruta = txtRuta.Text;
            if (Path.IsPathRooted(ruta) && Directory.Exists(Path.GetDirectoryName(ruta)))
            {
                if (isExcel(ruta))
                {
                    if (l_files.UploadFile(ruta, l_User.GetUserId()))
                    {
                        l_files.uploadFileToDir(ruta);
                        MessageBox.Show("se subio el archivo");
                        txtRuta.Text = "";
                        btnSubir.Visible = false;
                    }
                    else
                    {
                        MessageBox.Show("Nose pudo subir");
                    }
                }
                else
                {
                    MessageBox.Show("Archivo inconpatible");
                }
            }
            else
            {
                MessageBox.Show("Ruta no encontrada");
            }

        }

        // para verificar si el archivo es excel
        private bool isExcel(string rutaArchivo)
        {
            string extension = Path.GetExtension(rutaArchivo);
            return extension.Equals(".xls", StringComparison.OrdinalIgnoreCase) ||
                   extension.Equals(".xlsx", StringComparison.OrdinalIgnoreCase) ||
                   extension.Equals(".xlsm", StringComparison.OrdinalIgnoreCase) ||
                   extension.Equals(".xlsb", StringComparison.OrdinalIgnoreCase);
        }

        //actualizar archivos de usuario
        private void btnUpdateUserFiles_Click(object sender, EventArgs e)
        {
            filesForUser.DataSource = l_files.ls_files(l_User.GetUserId());
        }

        private void LlenarTreeView(string ruta, TreeNodeCollection parentNode)
        {
            try
            {
                DirectoryInfo directoryInfo = new DirectoryInfo(ruta);

                TreeNode parentNodeForCurrentDir = parentNode.Add(directoryInfo.Name);

                foreach (DirectoryInfo subDirectory in directoryInfo.GetDirectories())
                {
                    LlenarTreeView(subDirectory.FullName, parentNodeForCurrentDir.Nodes);
                }
                foreach (FileInfo file in directoryInfo.GetFiles())
                {
                    parentNodeForCurrentDir.Nodes.Add(file.Name);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al llenar el TreeView: {ex.Message}");
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            treeFiles.Nodes.Clear();
            LlenarTreeView(l_main.getUserPath(), treeFiles.Nodes);
        }

        private string rutaSeleccionada; // Declarar una variable para almacenar la ruta seleccionada

        private void treeFiles_AfterSelect(object sender, TreeViewEventArgs e)
        {
            // Obtener la ruta del nodo seleccionado
            TreeNode selectedNode = e.Node;
            rutaSeleccionada = ObtenerRutaCompleta(selectedNode);

            // Puedes guardar la ruta en una base de datos, en un archivo, en una variable, etc.
            // Por ejemplo, mostrar la ruta en una etiqueta o hacer algo más con ella.
            // Ejemplo: labelRuta.Text = rutaSeleccionada;

            // Luego de haber guardado la ruta, puedes realizar otras acciones según tus necesidades.
        }

        // Método para obtener la ruta completa de un nodo recursivamente
        private string ObtenerRutaCompleta(TreeNode node)
        {
            if (node == null)
                return "";

            string ruta = node.Text;

            while (node.Parent != null)
            {
                node = node.Parent;
                ruta = node.Text + "\\" + ruta;
            }

            return ruta;
        }

        private void treeFiles_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            string ruta = Path.GetFullPath(rutaSeleccionada);

            MessageBox.Show(ruta);
        }

        private void btnMoverAgestionCrearEmpresa_Click(object sender, EventArgs e)
        {
            controles.SelectedTab = tabPageEmpresas;
        }

        private void btnMoverAgestionEliminarEmpresa_Click(object sender, EventArgs e)
        {
            controles.SelectedTab = tabPageEmpresas;
            tabControlToGestionDeEmpresas.SelectedTab = tabeliminarEmpresa;
        }

        private void btnCrearEmpresa_Click(object sender, EventArgs e)
        {
            string empresa = txtCrearEmpresa.Text;

            if (!string.IsNullOrEmpty(empresa) && !string.IsNullOrWhiteSpace(empresa))
            {

                if (empresa.Contains(" "))
                {
                    MessageBox.Show("Los campos no deben contener espacios en blanco.", "Espacios en blanco", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    if (l_Empresa.crearEmpresa(empresa, l_User.GetUserId()))
                    {
                        MessageBox.Show("La empresa " + empresa + " a sido creado");
                        txtCrearEmpresa.Text = "";
                        actualizarEmpresas();
                        listadoEmpresas();
                    }
                    else
                    {
                        MessageBox.Show("La empresa ya existe");
                    }
                }
            }
            else
            {
                MessageBox.Show("Valor vacio");
            }

            
        }

        private void btnActualizarEmpresas_Click(object sender, EventArgs e)
        {
            actualizarEmpresas();
        }

        private void actualizarEmpresas()
        {
            dataGridViewforAllEmpresas.DataSource = l_Empresa.ls_files(l_User.GetUserId());
        }


        // tenog qeu solucionar esto xd
        private void btnEliminarEmpresa_Click(object sender, EventArgs e)
        {
            int empresaId;
            if (int.TryParse(txtEliminarEmpresa.Text, out empresaId))
            {
                if (l_Empresa.eliminarEmpresa(empresaId))
                {
                    MessageBox.Show("Se elimino empresa correctamente");
                    txtEliminarEmpresa.Text = "";
                    txtEliminarEmpresa.Focus();
                    actualizarEmpresas();
                    listadoEmpresas();
                }
                else
                {
                    MessageBox.Show("No se pudo eliminar la empresa verifica si la empresa existe");
                }
            }
            else
            {
                MessageBox.Show("Ingrese un valor correcto");
            }
        }

        private void btnMoverAfiles_Click(object sender, EventArgs e)
        {
            controles.SelectedTab = tabSubirArchivos;
        }

 
        //private void button3_Click(object sender, EventArgs e)
        //{
        //    if (button3.Text == "Editar")
        //    {
        //        txtPerfilEditarNombre.Enabled = true;
        //        button3.Text = "Cancelar";
        //        btnPerfilGuardar.Visible = true;
        //    }
        //    else
        //    {
        //        txtPerfilEditarNombre.Enabled = false;
        //        button3.Text = "Editar";
        //        btnPerfilGuardar.Visible = false;
        //    }
        //}


    }
}
