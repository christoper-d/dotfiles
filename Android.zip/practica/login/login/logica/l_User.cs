﻿using datos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace logica
{
    public class l_User
    {
        d_Users data = new d_Users();
        userData userData = new userData();

        public void load()
        {
            data.GetUserName();
        }

        public DataTable ls_users()
        {
            return data.ls_users();
        }

        public bool searchUser(string user)
        {
            return data.searchUser(user);
        }

        public bool changePassword(string user, string lastPassword, string newPassword)
        {
            return data.changePassword(user, lastPassword, newPassword);
        }

        //

        //public int GetUserId()
        //{
        //    int id = userData.userId;
        //    return id;
        //}

        public string GetUserName()
        {

            return data.GetUserName();
        }

        //public int GetUserPermissions()
        //{
        //    return userData.userPermissions;
        //}

    }
}
