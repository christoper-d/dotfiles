﻿using datos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace logica
{
    public class l_login
    {
        d_Users data = new d_Users();


        public bool login(string user, string pass)
        {
            return data.login(user, pass);
        }
    }
}
