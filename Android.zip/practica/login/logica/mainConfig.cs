﻿using datos;

namespace logica
{
    internal class mainConfig
    {
        /// <summary>
        /// Guarda el estado de la base de datos
        /// </summary>
        public bool dbState { get; set; }

        public string path { get; set; }
        public string userPath { get; set; }

        private static mainConfig _instance;

        private static readonly object lockObject = new object();

        private mainConfig() { }

        public static mainConfig Instance
        {
            get
            {
                if (_instance == null)
                {
                    lock (lockObject)
                    {
                        if (_instance == null)
                        {
                            _instance = new mainConfig();
                        }
                    }
                }
                return _instance;
            }
        }

    }
}
