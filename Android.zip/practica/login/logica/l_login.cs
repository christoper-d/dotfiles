﻿using datos;

namespace logica
{
    public class l_login
    {
        /// <summary>
        /// Instancia del modelo de users de la capa datos
        /// </summary>
        d_Users data = new d_Users();


        public bool login(string user, string pass)
        {
            return data.login(user, pass);
        }
    }
}
