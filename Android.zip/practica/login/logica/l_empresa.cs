﻿using datos;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace logica
{
    public class l_empresa
    {
        l_files l_Files = new l_files();
        d_empresas d_empresas = new d_empresas();


        public DataTable ls_files(int userId)
        {
            return d_empresas.ls_files(userId);
        }
        //
        public void buscarEmpresaPorId(int idEmpresa)
        {
            d_empresas.buscarEmpresaPorId(idEmpresa);
        }
        public void buscarEmpresaPorNombre(string empresaName)
        {
            d_empresas.buscarEmpresaPorNombre(empresaName);
        }

        //
        //public void sp_allEmpresas(int userId)
        //{
        //    d_empresas.sp_allEmpresas(userId);
        //}

        // ya funca
        public bool crearEmpresa(string empresa, int userId)
        {
            //l_Files.mkdir(empresa);
            return d_empresas.crearEmpresa(empresa, userId);
        }

        // falta solucionar esto
        public bool eliminarEmpresa(int empresaId)
        {
            d_empresas.buscarEmpresaPorId(empresaId);
            //l_Files.rmdir(d_empresas.getEmpresaName());
            return d_empresas.eliminarEmpresa(empresaId);
        }



        // Obtener datos de empresa
        public int getEmpresaId()
        {
            return d_empresas.getEmpresaId();
        }

        public string getEmpresaName()
        {
            return d_empresas.getEmpresaName();
        }
        public int getEmpresaUserId()
        {
            return d_empresas.getEmpresaUserId();
        }

        public string getEmpresaRuta()
        {
            return d_empresas.getEmpresaRuta();
        }
    }
}
