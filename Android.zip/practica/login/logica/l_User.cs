﻿using datos;
using System.Data;

namespace logica
{
    public class l_User
    {

        d_Users data = new d_Users();

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataTable ls_users()
        {
            return data.ls_users();
        }
        public bool searchUser(string user)
        {
            return data.searchUser(user);
        }

        public DataTable getUserInfobyId(int id)
        {
            return data.getUserInfobyId(id);
        }
        public bool changePassword(string user, string lastPassword, string newPassword)
        {
            return data.changePassword(user, lastPassword, newPassword);
        }

        public bool updateUser(int id, string username, string password, int permisos, int acceso)
        {
            return data.updateUser(id, username, password, permisos, acceso);
        }


        // to get user info
        /// <summary>
        /// retorna el id del usuario
        /// </summary>
        public int GetUserId()
        {
            return data.GetUserId();
        }
        /// <summary>
        /// retorna el nombre del usuario
        /// </summary>
        public string GetUserName()
        {

            return data.GetUserName();
        }
        /// <summary>
        /// retorna los permisos del usuario
        /// </summary>
        public int GetUserPermissions()
        {
            return data.GetUserPermissions();
        }

        // to admin
        public bool createUser(string userName, string userPassword, int permisos, int acceso)
        {
            return data.createUser(userName, userPassword, permisos, acceso);
        }

        public bool deleteUser(int userId)
        {
            return data.deleteUser(userId);
        }

    }
}
