﻿using datos;
using System.Data;
using System.IO;

namespace logica
{
    public class l_files
    {
        datos.userData userData = datos.userData.Instance;
        l_main l_Main = new l_main();
        d_files d_Files = new d_files();
        public bool UploadFile(string pathName, int userId)
        {
            return d_Files.uploadFile(pathName, userId);
        }

        public DataTable ls_files(int userId)
        {
            return d_Files.ls_files(userId);
        }


        public void uploadFileToDir(string filePath)
        {

            File.Copy(filePath, l_Main.getUserPath() + Path.GetFileName(filePath));
        }

        //
        

        //
        //public void mkdir( string name )
        //{
        //    l_Main.mkdir(name);
        //}

        //public void rmdir(string name)
        //{
        //    l_Main.rmdir(name);
        //}
    }
}
