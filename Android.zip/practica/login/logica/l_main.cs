﻿using datos;
using System;
using System.IO;

namespace logica
{
    public class l_main
    {
        logica.mainConfig config = logica.mainConfig.Instance;
        d_empresas d_empresas = new d_empresas();
        l_empresa l_Empresa = new l_empresa();
        l_User l_User = new l_User();




        public void loadConfi()
        {
            config.path = "C:\\contable\\users\\";
            this.makeStructure();
        }

        public void makeStructure()
        {
            

            if (!Directory.Exists(config.path))
            {
                Directory.CreateDirectory(config.path);
            }

            config.userPath = Path.Combine(config.path, l_User.GetUserName() + "\\");

            if (!Directory.Exists(config.userPath))
            {
                Directory.CreateDirectory(config.path + l_User.GetUserName() + "\\");
            }
        }



        public bool verificarEmpresas(string ruta)
        {
            try
            {
                if (!Directory.Exists(ruta))
                {
                    Directory.CreateDirectory(ruta);
                }

                return true; 
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
                return false;
            }
        }


        //public void mkdir(string name)
        //{
        //    string ruta = Path.Combine(config.userPath, name);
        //    if (!Directory.Exists(ruta))
        //    {
        //        d_empresas.setEmpresaRuta(ruta);
        //        Directory.CreateDirectory(ruta);
        //    }
        //}

        //// solcuionar el borrar direcotrios
        //public void rmdir(string name)
        //{
        //    string ruta = Path.Combine(config.userPath, name);
        //    if (!Directory.Exists(ruta))
        //    {
        //        Directory.Delete(ruta);
        //    }
        //}

        //public void loaddir(int userId)
        //{
        //    d_empresas.sp_allEmpresas(userId);
        //}


        //
        //public string getUserPath()
        //{
        //    return config.userPath;
        //}
    }
}
