﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;

namespace datos
{
    public class d_files
    {
        public DataTable ls_files(int userId)
        {
            SqlDataReader result;
            DataTable dt = new DataTable();
            SqlConnection sqlconn = new SqlConnection();
            try
            {
                sqlconn = conexion.GetConexion().newCon();
                //SOLO DE PRUEBA
                SqlCommand query = new SqlCommand("sp_getFilesOfUser", sqlconn);
                query.CommandType = CommandType.StoredProcedure;
                query.Parameters.Add("@userId", SqlDbType.Int).Value = userId;
                sqlconn.Open();
                result = query.ExecuteReader();
                dt.Load(result);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (sqlconn.State == ConnectionState.Open) sqlconn.Close();
            }
        }
        public bool uploadFile(string pathName, int userId)
        {
            byte[] contenidoArchivo = File.ReadAllBytes(pathName);
            string fileName = Path.GetFileName(pathName);
            SqlDataReader result;
            DataTable dt = new DataTable();
            SqlConnection sqlconn = new SqlConnection();

            try
            {
                sqlconn = conexion.GetConexion().newCon();
                SqlCommand query = new SqlCommand("sp_SubirArchivo", sqlconn);
                query.CommandType = CommandType.StoredProcedure;
                query.Parameters.Add("@nombreArchivo", SqlDbType.VarChar).Value = fileName;
                query.Parameters.Add("@contenidoArchivo", SqlDbType.VarBinary).Value = contenidoArchivo;
                query.Parameters.Add("@userId", SqlDbType.Int).Value = userId;
                sqlconn.Open();
                result = query.ExecuteReader();
                result.Read();
                if (Convert.ToInt32(result[0]) == 1)
                {
                    return true;
                }
                return false;
            }
            finally
            {
                if (sqlconn.State == ConnectionState.Open) sqlconn.Close();
            }
        }

    }
}
