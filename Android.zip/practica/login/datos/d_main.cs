﻿using System;
using System.Data.SqlClient;

namespace datos
{
    public class d_main
    {

        public bool isConnected()
        {
            try
            {
                using (SqlConnection con = conexion.GetConexion().newCon())
                {
                    con.Open();
                    return con.State == System.Data.ConnectionState.Open;
                }
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
