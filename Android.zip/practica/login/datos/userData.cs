﻿namespace datos
{
    /// <summary>
    /// Sirve para Obtener y Setear datos del usuario
    /// </summary>
    public class userData
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public int UserPermissions { get; set; }

        private static userData _instance;

        private static readonly object lockObject = new object();

        private userData() { }

        public static userData Instance
        {
            get
            {
                if (_instance == null)
                {
                    lock (lockObject)
                    {
                        if (_instance == null)
                        {
                            _instance = new userData();
                        }
                    }
                }
                return _instance;
            }
        }

    }
}
