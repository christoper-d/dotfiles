def saludo(fname, lname):
  print(fname + " " + lname)

saludo("Emil", "Refsnes")