drop table buzon;
drop table solicitudes;
drop table registros;
drop table clientes;
drop table estados;
drop table usuarios;

-- Tabla usuarios
CREATE TABLE usuarios (
    usuario_id INT PRIMARY KEY,
    nombre VARCHAR(255),
    usuario VARCHAR(250),
    contraseña VARCHAR(250),
    puesto VARCHAR(250),
    area_asignada VARCHAR(250),
    administrador_id INT null,
    FOREIGN KEY (administrador_id) REFERENCES usuarios(usuario_id)
);

-- Tabla solicitudes
CREATE TABLE solicitudes(
	solicitud_id INT IDENTITY(1,1) PRIMARY KEY,
	solicitud varchar(250)
);


-- Tabla buzon
CREATE TABLE buzon(
	buzon_id INT IDENTITY(1,1) PRIMARY KEY,
	usuario_id int,
	solicitud_id int
	FOREIGN KEY (usuario_id) REFERENCES usuarios(usuario_id) on delete cascade,
	FOREIGN KEY (solicitud_id) REFERENCES solicitudes(solicitud_id) on delete cascade
);

-- Tabla clientes
CREATE TABLE clientes(
	ruc INT  PRIMARY KEY,
	nombre varchar(250),
	ubicacion varchar(250),
	telefono int,
	usuario_id int,
	FOREIGN KEY (usuario_id) REFERENCES usuarios(usuario_id) on delete cascade,
);


-- Tabla estados
CREATE TABLE estados(
	estado_id INT IDENTITY(1,1) PRIMARY KEY,
	estado varchar(250)
);

-- Tabla registros
CREATE TABLE registros(
	registro_id INT PRIMARY KEY,
	ruc int,
	usuario_id int,
	estado_id int,
	FOREIGN KEY (ruc) REFERENCES clientes(ruc) ,
	FOREIGN KEY (usuario_id) REFERENCES usuarios(usuario_id) on delete cascade,
	FOREIGN KEY (estado_id) REFERENCES estados(estado_id) on delete cascade
);