﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace entidad
{
    public class empresaData
    {
        public int empresaId { get; set; }
        public string empresa { get; set; }
        public int userId { get; set; }
        public string ruta { get; set; }
        public List<string> empresas { get; set; }


        private static empresaData _instance;

        private static readonly object lockObject = new object();

        private empresaData() { }

        public static empresaData Instance
        {
            get
            {
                if (_instance == null)
                {
                    lock (lockObject)
                    {
                        if (_instance == null)
                        {
                            _instance = new empresaData();
                        }
                    }
                }
                return _instance;
            }
        }
    }
}
