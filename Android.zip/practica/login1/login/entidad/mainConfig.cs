﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace entidad
{
    public class mainConfig
    {
        public bool dbState { get; set; }

        public string path { get; set; }

        private static mainConfig _instance;

        private static readonly object lockObject = new object();

        private mainConfig() { }

        public static mainConfig Instance
        {
            get
            {
                if (_instance == null)
                {
                    lock (lockObject)
                    {
                        if (_instance == null)
                        {
                            _instance = new mainConfig();
                        }
                    }
                }
                return _instance;
            }
        }
    }
}
