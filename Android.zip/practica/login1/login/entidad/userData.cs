﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace entidad
{
    public class userData
    {
        public static userData _instance;

        public int UserId { get; set; }
        public string UserName { get; set; }
        public int UserPermissions { get; set; }
        public string userPath { get; set; }


        public userData()
        {
        }

        public static userData Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new userData();
                }
                return _instance;
            }
        }
    }
}
