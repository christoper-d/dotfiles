﻿using datos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace logica
{
    public class n_login
    {
        d_users data = new d_users();


        public bool login(string user, string pass)
        {
            return data.login(user, pass);
        }
    }
}
