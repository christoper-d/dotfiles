﻿using datos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace logica
{
    public class n_user
    {
        d_users data = new d_users();

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataTable ls_users()
        {
            return data.ls_users();
        }

        public DataTable allUsers()
        {
            return data.allUsers();
        }

        public bool searchUser(string user)
        {
            return data.searchUser(user);
        }

        public DataTable getUserInfobyId(int id)
        {
            return data.getUserInfobyId(id);
        }
        public DataTable getUserInfobyName(string name)
        {
            return data.getUserInfobyname(name);
        }
        public bool changePassword(string user, string lastPassword, string newPassword)
        {
            return data.changePassword(user, lastPassword, newPassword);
        }

        public bool updateUser(int id, string username, string password, int permisos, int acceso)
        {
            return data.updateUser(id, username, password, permisos, acceso);
        }


        // to get user info
        /// <summary>
        /// retorna el id del usuario
        /// </summary>
        public int GetUserId()
        {
            return data.GetUserId();
        }
        /// <summary>
        /// retorna el nombre del usuario
        /// </summary>
        public string GetUserName()
        {

            return data.GetUserName();
        }
        /// <summary>
        /// retorna los permisos del usuario
        /// </summary>
        public int GetUserPermissions()
        {
            return data.GetUserPermissions();
        }
        /// <summary>
        /// retorna la ruta del usuario
        /// </summary>
        public string GetUserPath()
        {
            return data.GetUserPath();
        }
        public void SetUserPath(string path)
        {
            data.SetUserPath(path);
        }


        /// to admin
        public bool createUser(string userName, string userPassword, int permisos, int acceso)
        {
            return data.createUser(userName, userPassword, permisos, acceso);
        }

        public bool deleteUser(string userId)
        {
            return data.deleteUser(userId);
        }

    }
}
