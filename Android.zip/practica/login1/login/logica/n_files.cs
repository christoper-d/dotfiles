﻿using datos;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace logica
{
    public class n_files
    {
        entidad.userData userData = entidad.userData.Instance;
        d_empresa d_Empresa = new d_empresa();
        //l_main l_Main = new l_main();
        d_files d_Files = new d_files();
        public bool UploadFile(string pathName, int userId, int empresaId)
        {
            return d_Files.uploadFile(pathName, userId, empresaId);
        }

        public DataTable ls_files(int userId)
        {
            return d_Files.ls_files(userId);
        }


        public void uploadFileToDir(string filePath, string finalPath)
        {
            File.Copy(filePath, finalPath + Path.GetFileName(filePath));
        }
    }
}
