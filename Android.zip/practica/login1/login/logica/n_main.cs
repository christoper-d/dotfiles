﻿using datos;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace logica
{
    public class n_main
    {
        entidad.mainConfig config = entidad.mainConfig.Instance;
        n_user n_User = new n_user();




        public void loadConfi()
        {
            this.makeStructure();
        }

        public void makeStructure()
        {
            config.path = "C:\\contable\\users\\";

            if (!Directory.Exists(config.path))
            {
                Directory.CreateDirectory(config.path);
            }

            n_User.SetUserPath(Path.Combine(config.path, n_User.GetUserName() + "\\"));

            if (!Directory.Exists(n_User.GetUserPath()))
            {
                Directory.CreateDirectory(config.path + n_User.GetUserName() + "\\");
            }
        }

        public string getConfigPath()
        {
            return config.path;
        }


        public bool crearLasRutasParaEmpresas(string ruta)
        {
            try
            {
                if (!Directory.Exists(ruta))
                {
                    Directory.CreateDirectory(ruta);
                }

                return true; 
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
                return false;
            }
        }

        //public void mkdir(string name)
        //{
        //    string ruta = Path.Combine(config.userPath, name);
        //    if (!Directory.Exists(ruta))
        //    {
        //        d_empresas.setEmpresaRuta(ruta);
        //        Directory.CreateDirectory(ruta);
        //    }
        //}

        //// solcuionar el borrar direcotrios
        //public void rmdir(string name)
        //{
        //    string ruta = Path.Combine(config.userPath, name);
        //    if (!Directory.Exists(ruta))
        //    {
        //        Directory.Delete(ruta);
        //    }
        //}

        //public void loaddir(int userId)
        //{
        //    d_empresas.sp_allEmpresas(userId);
        //}


        //
    }
}
