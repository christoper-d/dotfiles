﻿using datos;
using entidad;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace logica
{
    public class n_empresa
    {
        d_empresa d_Empresa = new d_empresa();
        d_users d_Users = new d_users();

        public DataTable ls_files(int userId)
        {
            return d_Empresa.ls_files(userId);
        }

        public DataTable sp_allEmpresas(int userId)
        {
            return d_Empresa.sp_allEmpresas(userId);
        }

        public bool crearEmpresa(string empresa, int userId)
        {
            //l_Files.mkdir(empresa);
            return d_Empresa.crearEmpresa(empresa, userId);
        }

        // falta solucionar esto
        public bool eliminarEmpresa(string empresaName)
        {
            d_Empresa.buscarEmpresaPorNombre(empresaName);
            //l_Files.rmdir(d_empresas.getEmpresaName());
            return d_Empresa.eliminarEmpresa(d_Empresa.getEmpresaId());
        }

        public bool eliminarCarpetaEmpresa(string empresaName)
        {
            string carpetaEmpresaPath = Path.Combine(d_Users.GetUserPath(), empresaName);

            if (Directory.Exists(carpetaEmpresaPath))
            {
                Directory.Delete(carpetaEmpresaPath, true);

                MessageBox.Show("Se elimino carpeta de empresa");
                return true;
            }
            else
            {
                MessageBox.Show("La empresa no existe. Verifica si la empresa existe.");
                return false;
            }
        } 

        //
        public void buscarEmpresaPorNombre(string empresaName)
        {
            d_Empresa.buscarEmpresaPorNombre(empresaName);
        }
        public void buscarEmpresaPorId(int idEmpresa)
        {
            d_Empresa.buscarEmpresaPorId(idEmpresa);
        }

        //
        public int getEmpresaId()
        {
            return d_Empresa.getEmpresaId();
        }

        public string getEmpresaName()
        {
            return d_Empresa.getEmpresaName();
            
        }
        public int getEmpresaUserId()
        {
            return d_Empresa.getEmpresaUserId();
        }

        public string getEmpresaRuta()
        {
            return d_Empresa.getEmpresaRuta();
        }

        public void setEmpresaRuta(string ruta)
        {
            setEmpresaRuta(ruta);
        }
    }
}
