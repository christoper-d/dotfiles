﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace datos
{
    public class d_empresa
    {
        d_users d_Users = new d_users();
        entidad.empresaData empresaData = entidad.empresaData.Instance;

        public DataTable ls_files(int userId)
        {
            SqlDataReader result;
            DataTable dt = new DataTable();
            SqlConnection sqlconn = new SqlConnection();
            try
            {
                sqlconn = conexion.GetConexion().newCon();
                //SOLO DE PRUEBA
                SqlCommand query = new SqlCommand("sp_lsEmpresas", sqlconn);
                query.CommandType = CommandType.StoredProcedure;
                query.Parameters.Add("@userId", SqlDbType.Int).Value = userId;
                sqlconn.Open();
                result = query.ExecuteReader();
                dt.Load(result);
                return dt;
            }

            finally
            {
                if (sqlconn.State == ConnectionState.Open) sqlconn.Close();
            }
        }

        public DataTable sp_allEmpresas(int userId)
        {
            SqlDataReader result;
            DataTable dt = new DataTable();
            SqlConnection sqlconn = new SqlConnection();

            try
            {
                sqlconn = conexion.GetConexion().newCon();
                SqlCommand query = new SqlCommand("sp_allEmpresas", sqlconn);
                query.CommandType = CommandType.StoredProcedure;
                query.Parameters.Add("@userId", SqlDbType.Int).Value = userId;
                sqlconn.Open();
                result = query.ExecuteReader();
                dt.Load(result);
                return dt;
            }
            finally
            {
                if (sqlconn.State == ConnectionState.Open) sqlconn.Close();
            }
        }

        public void buscarEmpresaPorId(int idEmpresa)
        {
            SqlDataReader result;
            SqlConnection sqlconn = new SqlConnection();

            try
            {
                sqlconn = conexion.GetConexion().newCon();
                SqlCommand query = new SqlCommand("buscarEmpresaPorId", sqlconn);
                query.CommandType = CommandType.StoredProcedure;
                query.Parameters.Add("@empresaId", SqlDbType.Int).Value = idEmpresa;
                sqlconn.Open();
                result = query.ExecuteReader();
                result.Read();
                int empresaId = result.GetInt32(result.GetOrdinal("Identificador"));
                string empresa = result.GetString(result.GetOrdinal("Empresa"));
                int usuario = result.GetInt32(result.GetOrdinal("Usuario"));


                empresaData.empresaId = empresaId;
                empresaData.empresa = empresa;
                empresaData.userId = usuario;
            }
            finally
            {
                if (sqlconn.State == ConnectionState.Open) sqlconn.Close();
            }
        }

        public void buscarEmpresaPorNombre(string empresaName)
        {
            SqlDataReader result;
            SqlConnection sqlconn = new SqlConnection();

            try
            {
                sqlconn = conexion.GetConexion().newCon();
                SqlCommand query = new SqlCommand("buscarEmpresaPorNombre", sqlconn);
                query.CommandType = CommandType.StoredProcedure;
                query.Parameters.Add("@empresaNombre", SqlDbType.VarChar).Value = empresaName;
                sqlconn.Open();
                result = query.ExecuteReader();
                result.Read();
                int empresaId = result.GetInt32(result.GetOrdinal("Identificador"));
                string empresa = result.GetString(result.GetOrdinal("Empresa"));
                int usuario = result.GetInt32(result.GetOrdinal("Usuario"));


                empresaData.empresaId = empresaId;
                empresaData.empresa = empresa;
                empresaData.userId = usuario;
            }
            finally
            {
                if (sqlconn.State == ConnectionState.Open) sqlconn.Close();
            }
        }


        // ------------------Crear y eliminar
        public bool crearEmpresa(string empresa, int userId)
        {
            SqlDataReader result;
            DataTable dt = new DataTable();
            SqlConnection sqlconn = new SqlConnection();

            try
            {
                sqlconn = conexion.GetConexion().newCon();
                SqlCommand query = new SqlCommand("CrearEmpresa", sqlconn);
                query.CommandType = CommandType.StoredProcedure;
                query.Parameters.Add("@nombreEmpresa", SqlDbType.VarChar).Value = empresa;
                query.Parameters.Add("@userId", SqlDbType.Int).Value = userId;
                sqlconn.Open();
                result = query.ExecuteReader();
                result.Read();
                if (Convert.ToInt32(result[0]) == 1)
                {
                    return true;
                }
                return false;
            }
            finally
            {
                if (sqlconn.State == ConnectionState.Open) sqlconn.Close();
            }
        }

        //eliminarEmpresa

        public bool eliminarEmpresa(int empresaId)
        {
            SqlDataReader result;
            DataTable dt = new DataTable();
            SqlConnection sqlconn = new SqlConnection();

            try
            {
                sqlconn = conexion.GetConexion().newCon();
                SqlCommand query = new SqlCommand("eliminarEmpresa", sqlconn);
                query.CommandType = CommandType.StoredProcedure;
                query.Parameters.Add("@empresaId", SqlDbType.Int).Value = empresaId;
                query.Parameters.Add("@userId", SqlDbType.Int).Value = d_Users.GetUserId();
                sqlconn.Open();
                result = query.ExecuteReader();
                result.Read();
                if (Convert.ToInt32(result[0]) == 1)
                {
                    return true;
                }
                return false;
            }
            finally
            {
                if (sqlconn.State == ConnectionState.Open) sqlconn.Close();
            }
        }

        public int getEmpresaId()
        {
            return empresaData.empresaId;
        }

        public string getEmpresaName()
        {
            return empresaData.empresa;
        }
        public int getEmpresaUserId()
        {
            return empresaData.userId;
        }

        public string getEmpresaRuta()
        {
            return empresaData.ruta;
        }

        public void setEmpresaRuta(string ruta)
        {
            empresaData.ruta = ruta;
        }

    }
}
