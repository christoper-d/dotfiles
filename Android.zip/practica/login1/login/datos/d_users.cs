﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace datos
{
    public class d_users
    {
        entidad.userData userData = entidad.userData.Instance;

        public DataTable ls_users()
        {
            SqlDataReader result;
            DataTable dt = new DataTable();
            SqlConnection sqlconn = new SqlConnection();
            try
            {
                sqlconn = conexion.GetConexion().newCon();
                //SOLO DE PRUEBA
                SqlCommand query = new SqlCommand("select id as ID,username as Nombre, password1 as Contraseña,CASE WHEN permisos = 1 THEN 'Administrador' ELSE 'Usuario' END AS permisos,CASE WHEN acceso = 1 THEN 'Denegado' ELSE 'Activado' END AS acceso from users;", sqlconn);
                query.CommandType = CommandType.Text;
                sqlconn.Open();
                result = query.ExecuteReader();
                dt.Load(result);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (sqlconn.State == ConnectionState.Open) sqlconn.Close();
            }
        }

        public DataTable allUsers()
        {
            SqlDataReader result;
            DataTable dt = new DataTable();
            SqlConnection sqlconn = new SqlConnection();
            try
            {
                sqlconn = conexion.GetConexion().newCon();
                //SOLO DE PRUEBA
                SqlCommand query = new SqlCommand("select CASE WHEN username = 'admin' THEN '' ELSE username END AS Nombre from users;", sqlconn);
                query.CommandType = CommandType.Text;
                sqlconn.Open();
                result = query.ExecuteReader();
                dt.Load(result);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (sqlconn.State == ConnectionState.Open) sqlconn.Close();
            }
        }

        public bool login(string user, string pass)
        {
            SqlDataReader result;
            DataTable dt = new DataTable();
            SqlConnection sqlconn = new SqlConnection();
            try
            {
                sqlconn = conexion.GetConexion().newCon();
                SqlCommand query = new SqlCommand("sp_Login", sqlconn);
                query.CommandType = CommandType.StoredProcedure;
                query.Parameters.Add("@username", SqlDbType.VarChar).Value = user;
                query.Parameters.Add("@password", SqlDbType.VarChar).Value = pass;
                sqlconn.Open();
                result = query.ExecuteReader();
                result.Read();
                if (Convert.ToInt32(result[0]) == 1)
                {
                    GetUserInfo(user);
                    return true;
                }
                return false;
            }
            finally
            {
                if (sqlconn.State == ConnectionState.Open) sqlconn.Close();
            }
        }

        public bool searchUser(string user)
        {
            SqlDataReader result;
            DataTable dt = new DataTable();
            SqlConnection sqlconn = new SqlConnection();
            try
            {
                sqlconn = conexion.GetConexion().newCon();
                SqlCommand query = new SqlCommand("sp_searchUser", sqlconn);
                query.CommandType = CommandType.StoredProcedure;
                query.Parameters.Add("@user", SqlDbType.VarChar).Value = user;
                sqlconn.Open();
                result = query.ExecuteReader();
                dt.Load(result);
                if (dt.Rows.Count > 0)
                {
                    return true;
                }
                return false;
            }
            finally
            {
                if (sqlconn.State == ConnectionState.Open) sqlconn.Close();
            }
        }

        public DataTable getUserInfobyId(int id)
        {
            SqlDataReader result;
            DataTable dt = new DataTable();
            SqlConnection sqlconn = new SqlConnection();
            try
            {
                sqlconn = conexion.GetConexion().newCon();
                SqlCommand query = new SqlCommand("sp_GetUserInfobyId", sqlconn);
                query.CommandType = CommandType.StoredProcedure;
                query.Parameters.Add("@userId", SqlDbType.VarChar).Value = id;
                sqlconn.Open();
                result = query.ExecuteReader();
                dt.Load(result);
                return dt;
            }
            finally
            {
                if (sqlconn.State == ConnectionState.Open) sqlconn.Close();
            }
        }

        public DataTable getUserInfobyname(string name)
        {
            SqlDataReader result;
            DataTable dt = new DataTable();
            SqlConnection sqlconn = new SqlConnection();
            try
            {
                sqlconn = conexion.GetConexion().newCon();
                SqlCommand query = new SqlCommand("sp_GetUserInfobyName", sqlconn);
                query.CommandType = CommandType.StoredProcedure;
                query.Parameters.Add("@userName", SqlDbType.VarChar).Value = name;
                sqlconn.Open();
                result = query.ExecuteReader();
                dt.Load(result);
                return dt;
            }
            finally
            {
                if (sqlconn.State == ConnectionState.Open) sqlconn.Close();
            }
        }

        // to get user info
        public void GetUserInfo(string username)
        {
            SqlDataReader result;
            SqlConnection sqlconn = new SqlConnection();

            try
            {
                sqlconn = conexion.GetConexion().newCon();
                SqlCommand query = new SqlCommand("sp_GetUserInfo", sqlconn);
                query.CommandType = CommandType.StoredProcedure;
                query.Parameters.Add("@username", SqlDbType.VarChar).Value = username;
                sqlconn.Open();
                result = query.ExecuteReader();
                result.Read();
                int id = result.GetInt32(result.GetOrdinal("UserID"));
                string user = result.GetString(result.GetOrdinal("UserName"));
                int Permissions = result.GetInt32(result.GetOrdinal("UserPermissions"));


                userData.UserId = id;
                userData.UserName = user;
                userData.UserPermissions = Permissions;
            }
            finally
            {
                if (sqlconn.State == ConnectionState.Open) sqlconn.Close();
                GetUserName();
            }
        }

        public int GetUserId()
        {
            return userData.UserId;
        }

        public string GetUserName()
        {
            return userData.UserName;
        }

        public int GetUserPermissions()
        {
            return userData.UserPermissions;
        }

        public string GetUserPath()
        {
            return userData.userPath;
        }

        public void SetUserPath( string path)
        {
            userData.userPath = path;
        }

        //to admin
        public bool createUser(string username, string password, int permisos, int acceso)
        {
            SqlDataReader result;
            DataTable dt = new DataTable();
            SqlConnection sqlconn = new SqlConnection();

            try
            {
                sqlconn = conexion.GetConexion().newCon();
                SqlCommand query = new SqlCommand("sp_createUser", sqlconn);
                query.CommandType = CommandType.StoredProcedure;
                query.Parameters.Add("@username", SqlDbType.VarChar).Value = username;
                query.Parameters.Add("@password", SqlDbType.VarChar).Value = password;
                query.Parameters.Add("@permisos", SqlDbType.Int).Value = permisos;
                query.Parameters.Add("@acceso", SqlDbType.Int).Value = acceso;
                sqlconn.Open();
                result = query.ExecuteReader();
                result.Read();
                if (Convert.ToInt32(result[0]) == 1)
                {
                    return true;
                }
                return false;
            }
            finally
            {
                if (sqlconn.State == ConnectionState.Open) sqlconn.Close();
                GetUserName();
            }
        }

        public bool updateUser(int id, string username, string password, int permisos, int acceso)
        {
            SqlDataReader result;
            DataTable dt = new DataTable();
            SqlConnection sqlconn = new SqlConnection();
            try
            {
                sqlconn = conexion.GetConexion().newCon();
                SqlCommand query = new SqlCommand("sp_updateUser", sqlconn);
                query.CommandType = CommandType.StoredProcedure;
                query.Parameters.Add("@id", SqlDbType.Int).Value = id;
                query.Parameters.Add("@username", SqlDbType.VarChar).Value = username;
                query.Parameters.Add("@password", SqlDbType.VarChar).Value = password;
                query.Parameters.Add("@permisos", SqlDbType.Int).Value = permisos;
                query.Parameters.Add("@acceso", SqlDbType.Int).Value = acceso;

                sqlconn.Open();
                result = query.ExecuteReader();
                result.Read();
                if (Convert.ToInt32(result[0]) == 1)
                {
                    return true;
                }
                return false;
            }
            finally
            {
                if (sqlconn.State == ConnectionState.Open) sqlconn.Close();
            }
        }

        public bool deleteUser(string userName)
        {
            SqlDataReader result;
            DataTable dt = new DataTable();
            SqlConnection sqlconn = new SqlConnection();

            try
            {
                sqlconn = conexion.GetConexion().newCon();
                SqlCommand query = new SqlCommand("sp_EliminarUsuario", sqlconn);
                query.CommandType = CommandType.StoredProcedure;
                query.Parameters.Add("@userName", SqlDbType.VarChar).Value = userName;
                sqlconn.Open();
                result = query.ExecuteReader();
                result.Read();
                if (Convert.ToInt32(result[0]) == 1)
                {
                    return true;
                }
                return false;
            }
            finally
            {
                if (sqlconn.State == ConnectionState.Open) sqlconn.Close();
                GetUserName();
            }
        }

        public bool changePassword(string user, string lastPassword, string newPassword)
        {
            SqlDataReader result;
            DataTable dt = new DataTable();
            SqlConnection sqlconn = new SqlConnection();
            try
            {
                sqlconn = conexion.GetConexion().newCon();
                SqlCommand query = new SqlCommand("sp_changePassword", sqlconn);
                query.CommandType = CommandType.StoredProcedure;
                query.Parameters.Add("@user", SqlDbType.VarChar).Value = user;
                query.Parameters.Add("@lastPassword", SqlDbType.VarChar).Value = lastPassword;
                query.Parameters.Add("@newPassword", SqlDbType.VarChar).Value = newPassword;
                sqlconn.Open();
                result = query.ExecuteReader();
                result.Read();
                if (Convert.ToInt32(result[0]) == 1)
                {
                    return true;
                }
                return false;
            }
            finally
            {
                if (sqlconn.State == ConnectionState.Open) sqlconn.Close();
            }
        }

    }
}
