﻿using logica;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;

namespace login
{
    public partial class main : Form
    {
        n_user n_User = new n_user();
        n_main n_Main = new n_main();
        n_files n_Files = new n_files();
        n_empresa n_Empresa = new n_empresa();


        public main()
        {
            InitializeComponent();
        }

        public void forAdmin()
        {
            allUsers.DataSource = n_User.ls_users();
            //config
            comBoxPermisos.SelectedIndex = 1;
            comBoxAcceso.SelectedIndex = 0;



            // para eliminar los tabs y solo dejar gestion de usuario
            // para eliminar los tabs y solo dejar gestion de usuario
            tabControlPrincipal.TabPages.Remove(tabPageInicio);
            tabControlPrincipal.TabPages.Remove(tabPageArchivos);
            tabControlPrincipal.TabPages.Remove(tabPageEmpresas);

            //
            actualizaruserstoeditodelete();

        }

        private void actualizaruserstoeditodelete()
        {
            LlenarComboBoxUsers(comBoxUserForDelete);
            LlenarComboBoxUsers(comBoxEditarUser);
        }

        private void forUser()
        {
            tabControlPrincipal.TabPages.Remove(tabPage2);
            //filesForUser.DataSource = l_files.ls_files(l_User.GetUserId());
            //dataGridViewforAllEmpresas.DataSource = l_Empresa.ls_files(l_User.GetUserId());
            //nose no se establece la ruta
            //listadoEmpresas();
            //lbUser.Text = l_User.GetUserName();
            actualizarFiles();
            actualizarEmpresas();
            LlenarTreeView(Path.GetFullPath(n_User.GetUserPath()), treeFiles.Nodes);
        }

        public void load()
        {
            n_Main.loadConfi();
            if (n_User.GetUserPermissions() == 1)
            {
                forAdmin();
            }
            else
            {
                forUser();
            }
        }

        private void main_Load(object sender, EventArgs e)
        {
            loginForm login = new loginForm();
            if (login.ShowDialog() != DialogResult.OK)
            {
                Application.Exit();
            }

            //this.ls_users();
            this.load();
        }

        private void btnMoverArchivos_Click(object sender, EventArgs e)
        {
            tabControlPrincipal.SelectedTab = tabPageArchivos;
        }

        private void btnMoverAempresaCrear_Click(object sender, EventArgs e)
        {
            tabControlPrincipal.SelectedTab = tabPageEmpresas;
        }

        private void btnMoverAempresaEliminarEmpresa_Click(object sender, EventArgs e)
        {
            tabControlPrincipal.SelectedTab = tabPageEmpresas;
            tabControlToGestionDeEmpresas.SelectedTab = tabeliminarEmpresa;
        }

        private void LlenarTreeView(string ruta, TreeNodeCollection parentNode)
        {
            try
            {
                DirectoryInfo directoryInfo = new DirectoryInfo(ruta);

                TreeNode parentNodeForCurrentDir = parentNode.Add(directoryInfo.Name);

                foreach (DirectoryInfo subDirectory in directoryInfo.GetDirectories())
                {
                    LlenarTreeView(subDirectory.FullName, parentNodeForCurrentDir.Nodes);
                }
                foreach (FileInfo file in directoryInfo.GetFiles())
                {
                    parentNodeForCurrentDir.Nodes.Add(file.Name);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al llenar el TreeView: {ex.Message}");
            }
        }

        private void LlenarComboBox(int userId, ComboBox comboBox)
        {
            DataTable dt = n_Empresa.sp_allEmpresas(userId);

            comboBox.Items.Clear();

            foreach (DataRow row in dt.Rows)
            {
                if (n_Main.crearLasRutasParaEmpresas(n_User.GetUserPath() + row["Nombre"].ToString()))

                    comboBox.Items.Add(row["Nombre"].ToString());
            }

            if (comboBox.Items.Count > 0)
            {
                comboBox.SelectedIndex = 0;
            }
            else
            {
                comboBox.Text = string.Empty;
                comboBox.Enabled = false;
            }
        }

        private void LlenarComboBoxUsers(ComboBox comboBox)
        {
            DataTable dt = n_User.allUsers();

            comboBox.Items.Clear();

            foreach (DataRow row in dt.Rows)
            {
                if (n_Main.crearLasRutasParaEmpresas(n_User.GetUserPath() + row["Nombre"].ToString()))

                    comboBox.Items.Add(row["Nombre"].ToString());
            }

            if (comboBox.Items.Count > 0)
            {
                comboBox.SelectedIndex = 0;
            }
            else
            {
                comboBox.Enabled = false;
            }
        }



        //  Cerrar sesion y Salir
        private void btnCerrarSesion_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        //

        private void btnActualizarEmpresas_Click_1(object sender, EventArgs e)
        {
            actualizarEmpresas();
            
        }

        private void actualizarEmpresas()
        {
            LlenarComboBox(n_User.GetUserId(), comboxEmpresasUploadFile);
            LlenarComboBox(n_User.GetUserId(), comBoxEliminarEmpresa);
            dataGridViewforAllEmpresas.DataSource = n_Empresa.ls_files(n_User.GetUserId());
        }

        private void actualizarFiles()
        {
            filesForUser.DataSource = n_Files.ls_files(n_User.GetUserId());
        }

        // Treeview
        private void button2_Click(object sender, EventArgs e)
        {
            treeFiles.Nodes.Clear();
            LlenarTreeView(Path.GetFullPath(n_User.GetUserPath()), treeFiles.Nodes);
        }
        private string rutaSeleccionada;
        private void treeFiles_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            //string ruta = Path.GetPathRoot(rutaSeleccionada);
            string ruta = Path.GetFullPath(n_Main.getConfigPath() + rutaSeleccionada);
            //if (Directory.Exists(ruta))
            //{
            //    MessageBox.Show(ruta);
            //}

            if (Directory.Exists(ruta))
            {
                // If it's a directory, open it using the default file explorer
                Process.Start("explorer.exe", ruta);
            }
            else if (File.Exists(ruta))
            {
                // If it's a file, open it using the default associated application
                Process.Start(ruta);
            }
        }

        private void treeFiles_AfterSelect(object sender, TreeViewEventArgs e)
        {
            rutaSeleccionada = "";
            recursivo(e.Node);
        }

        private void recursivo(TreeNode nodo)
        {
            if (nodo.Parent == null)
            {
                rutaSeleccionada += "/" + nodo.Text;
            }
            else
            {
                recursivo(nodo.Parent);
                rutaSeleccionada += "/" + nodo.Text;
            }

            //if (e.Node.Parent == null)
            //{
            //    string child = e.Node.Text;
            //    rutaSeleccionada = "/" + child;
            //}
            //else
            //{
            //    string parent = e.Node.Parent.Text;
            //    string child = e.Node.Text;
            //    rutaSeleccionada = parent + "/" + child;
            //}
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Title = "Seleccionar archivo";
            openFileDialog.Filter = "Archivos de texto|*.xlsx|Todos los archivos|*.*";

            DialogResult result = openFileDialog.ShowDialog();

            if (result == DialogResult.OK)
            {
                string rutaArchivo = openFileDialog.FileName;
                txtRuta.Text = rutaArchivo;
                btnSubir.Visible = true;
            }
        }

        private void btnSubir_Click(object sender, EventArgs e)
        {
            string ruta = txtRuta.Text;
            string empresaName = comboxEmpresasUploadFile.Text;

            if (!string.IsNullOrEmpty(empresaName) && !string.IsNullOrWhiteSpace(empresaName))
            {
                if (Path.IsPathRooted(ruta) && Directory.Exists(Path.GetDirectoryName(ruta)))
                {
                    if (isExcel(ruta))
                    {
                        n_Empresa.buscarEmpresaPorNombre(empresaName);
                        if (n_Files.UploadFile(ruta, n_User.GetUserId(),n_Empresa.getEmpresaId()))
                        {
                            n_Files.uploadFileToDir(ruta, n_Empresa.getEmpresaRuta());
                            MessageBox.Show("se subio el archivo");
                            txtRuta.Text = "";
                            btnSubir.Visible = false;
                            actualizarFiles();
                        }
                        else
                        {
                            MessageBox.Show("Nose pudo subir");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Archivo inconpatible");
                    }
                }
                else
                {
                    MessageBox.Show("Ruta no encontrada");
                }
            }
            else
            {
                MessageBox.Show("selecione una empresa o cree una");
            }

        }

        private bool isExcel(string rutaArchivo)
        {
            string extension = Path.GetExtension(rutaArchivo);
            return extension.Equals(".xls", StringComparison.OrdinalIgnoreCase) ||
                   extension.Equals(".xlsx", StringComparison.OrdinalIgnoreCase) ||
                   extension.Equals(".xlsm", StringComparison.OrdinalIgnoreCase) ||
                   extension.Equals(".xlsb", StringComparison.OrdinalIgnoreCase);
        }

        private void btnCrearUsuario_Click(object sender, EventArgs e)
        {
            string userName = txtUserNameToNewUser.Text;
            string userPassword = txtUserPasswordToNewUser.Text;
            string userPermisosTxt = comBoxPermisos.Text;
            string userAccesoTxt = comBoxAcceso.Text;
            int userPermisos = 0;
            int acceso = 0;



            if (!string.IsNullOrEmpty(userName) && !string.IsNullOrEmpty(userPassword) && !string.IsNullOrEmpty(userPermisosTxt) && !string.IsNullOrEmpty(userAccesoTxt)
                && !string.IsNullOrWhiteSpace(userName) && !string.IsNullOrWhiteSpace(userPassword)
                )
            {
                if (userPermisosTxt == "Administrador")
                {
                    userPermisos = 1;
                }

                if (userAccesoTxt == "Denegado")
                {
                    acceso = 1;
                }

                if (userName.Contains(" ") || userPassword.Contains(" "))
                {
                    MessageBox.Show("Los campos no deben contener espacios en blanco.", "Espacios en blanco", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    if (n_User.createUser(userName, userPassword, userPermisos, acceso))
                    {
                        MessageBox.Show("El Usuario " + userName + " Sido creado");
                        txtUserNameToNewUser.Text = "";
                        txtUserPasswordToNewUser.Text = "";
                        comBoxPermisos.SelectedIndex = 1;
                        comBoxAcceso.SelectedIndex = 0;
                        txtUserNameToNewUser.Focus();
                        updateTableOfUsers();
                        actualizaruserstoeditodelete();
                    }
                    else
                    {
                        MessageBox.Show("El Usuario Ya Existe");
                    }
                }
            }
            else
            {
                MessageBox.Show("Algun valor vacio");
            }
        }

        string idEditUser;
        private void btnBuscarUsuario_Click(object sender, EventArgs e)
        {
            //comBoxEditarUser
            string userToEdit = comBoxEditarUser.Text;

            if (!string.IsNullOrEmpty(userToEdit) && !string.IsNullOrWhiteSpace(userToEdit))
            {
                DataTable userInfo = n_User.getUserInfobyName(userToEdit);
                if (n_User.getUserInfobyName(userToEdit).Rows.Count > 0)
                {
                    txtForMessageEditar.Text = "Listo para editar";
                    editForm(true);
                    foreach (DataRow row in userInfo.Rows)
                    {
                        idEditUser = row["UserID"].ToString();
                        txtEditName.Text = row["UserName"].ToString();
                        txtEditPassword.Text = row["UserPassword"].ToString();
                        if (Convert.ToInt32(row["UserPermissions"]) == 0)
                        {
                            comBoxEditarPermisos.SelectedIndex = 1;
                        }
                        else
                        {
                            comBoxEditarPermisos.SelectedIndex = 0;
                        }
                        //Activado 1 
                        //Denegado 0
                        if (Convert.ToInt32(row["UserAcceso"]) == 1)
                        {
                            comBoxEditarAcceso.SelectedIndex = 1;
                        }
                        else
                        {
                            comBoxEditarAcceso.SelectedIndex = 0;
                        }
                    }
                }
                else
                {
                    txtForMessageEditar.Text = "Usuario no encontrado";

                    editForm(false);

                }
            }
            else
            {
                txtForMessageEditar.Text = "Ingrese un valor valido";
                editForm(false);
            }
        }
        
        private void editForm(bool action)
        {
            //label
            lbForEditarName.Visible = action;
            lbForEditarPassword.Visible = action;
            lbForEditarPermisos.Visible = action;
            lbForEditarAcceso.Visible = action;
            //textbox
            txtEditName.Visible = action;
            txtEditPassword.Visible = action;
            comBoxEditarPermisos.Visible = action;
            comBoxEditarAcceso.Visible = action;
            //butons
            btnGuardarCambios.Visible = action;
            btnEditarCancelar.Visible = action;
        }

        private void btnGuardarCambios_Click(object sender, EventArgs e)
        {
            string newName = txtEditName.Text;
            string newPassword = txtEditPassword.Text;
            int newPermiso = 0;
            int newAcceso = 0;

            if (!string.IsNullOrEmpty(txtEditName.Text) && !string.IsNullOrEmpty(txtEditPassword.Text) && !string.IsNullOrEmpty(comBoxEditarPermisos.Text))
            {
                // Para permisos
                if (comBoxEditarPermisos.Text == "Administrador")
                {
                    newPermiso = 1;
                }
                // Para acceso
                if (comBoxEditarAcceso.Text == "Denegado")
                {
                    newAcceso = 1;
                }

                if (newName.Contains(" ") || newPassword.Contains(" "))
                {
                    MessageBox.Show("Los campos no deben contener espacios en blanco.", "Espacios en blanco", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    if (n_User.updateUser(int.Parse(idEditUser), newName, newPassword, newPermiso, newAcceso))
                    {
                        MessageBox.Show("Usuario actualizado");

                        txtForMessageEditar.Text = "";
                        editForm(false);
                        updateTableOfUsers();
                        actualizaruserstoeditodelete();
                    }
                    else
                    {
                        MessageBox.Show("Error al actualizar usuario");
                    }
                }

            }
            else
            {
                lbForEdit.Text = "Algun valor vacio";
            }
        }

        private void btnEditarCancelar_Click(object sender, EventArgs e)
        {
            txtForMessageEditar.Text = "";
            editForm(false);
        }

        private void btnEliminarUser_Click(object sender, EventArgs e)
        {
            string userNameToDelete = comBoxUserForDelete.Text;
            if (!string.IsNullOrEmpty(userNameToDelete) && !string.IsNullOrWhiteSpace(userNameToDelete))
            {
                if (n_User.deleteUser(userNameToDelete))
                {
                    MessageBox.Show("Se elimino usuario correctamente");
                    txtUserId.Text = "";
                    txtUserId.Focus();
                    updateTableOfUsers();
                }
                else
                {
                    MessageBox.Show("No se pudo eliminar el usuario verifica si el usuario existe");
                }
            }
            else
            {
                MessageBox.Show("Ingrese un valor correcto");
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            updateTableOfUsers();
            actualizaruserstoeditodelete();
        }

        private void updateTableOfUsers()
        {
            allUsers.DataSource = n_User.ls_users();
        }

        private void btnUpdateUserFiles_Click(object sender, EventArgs e)
        {
            actualizarFiles();
            actualizarEmpresas();
        }

        private void btnCrearEmpresa_Click(object sender, EventArgs e)
        {
            string empresa = txtCrearEmpresa.Text;

            if (!string.IsNullOrEmpty(empresa) && !string.IsNullOrWhiteSpace(empresa))
            { 
                    if (n_Empresa.crearEmpresa(empresa, n_User.GetUserId()))
                    {
                        MessageBox.Show("La empresa " + empresa + " a sido creado");
                        txtCrearEmpresa.Text = "";
                        LlenarComboBox(n_User.GetUserId(), comBoxEliminarEmpresa);
                        listadoEmpresas();
                        actualizarEmpresas();
                    }
                    else
                    {
                        MessageBox.Show("La empresa ya existe");
                    }
                
            }
            else
            {
                MessageBox.Show("Valor vacio");
            }
        }

        private void listadoEmpresas()
        {
            LlenarComboBoxConCarpetas(Path.GetFullPath(n_User.GetUserPath()));
        }

        private void LlenarComboBoxConCarpetas(string rutaDirectorio)
        {
            // Verifica si el directorio existe
            if (Directory.Exists(rutaDirectorio))
            {
                // Obtiene los nombres de las carpetas en el directorio
                string[] carpetas = Directory.GetDirectories(rutaDirectorio);

                // Limpia el ComboBox antes de agregar nuevos elementos
                comboxEmpresasUploadFile.Items.Clear();

                // Agrega los nombres de las carpetas al ComboBox
                foreach (string carpeta in carpetas)
                {
                    string nombreCarpeta = Path.GetFileName(carpeta);
                    comboxEmpresasUploadFile.Items.Add(nombreCarpeta);
                }
            }
            else
            {
                MessageBox.Show("El directorio no existe.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEliminarEmpresa_Click(object sender, EventArgs e)
        {
            string empresaName = comBoxEliminarEmpresa.Text;
            if (!string.IsNullOrEmpty(comBoxEliminarEmpresa.Text))
            {

                DialogResult resultado = MessageBox.Show($"¿Seguro que quieres eliminar la empresa {empresaName}?", "Confirmar Eliminación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (resultado == DialogResult.Yes) { 
                    if (n_Empresa.eliminarEmpresa(empresaName) && n_Empresa.eliminarCarpetaEmpresa(empresaName))
                    {
                        MessageBox.Show("Se elimino empresa correctamente");
                        comBoxEliminarEmpresa.SelectedIndex = 0;
                        comBoxEliminarEmpresa.Focus();
                        actualizarEmpresas();
                        listadoEmpresas();
                    }
                    else
                    {
                        MessageBox.Show("No se pudo eliminar la empresa verifica si la empresa existe");
                    }
                }
            }
            else
            {
                MessageBox.Show("Ingrese un valor correcto");
            }
        }


        private void btnMoverAempresaCrear_MouseHover_1(object sender, EventArgs e)
        {
            allHover(btnMoverAempresaCrear, "hover");

        }

        private void btnMoverAempresaCrear_MouseLeave(object sender, EventArgs e)
        {
            allHover(btnMoverAempresaCrear, "leave");
        }
        private void allHover(Button boton, string opcion)
        {
            switch (opcion)
            {
                case ("hover"):
                    boton.BackColor = Color.Black;
                    boton.ForeColor = Color.White;
                    break;

                case ("leave"):
                    boton.BackColor = Color.White;
                    boton.ForeColor = Color.Black;
                    break;
            }
        }
    }

}
