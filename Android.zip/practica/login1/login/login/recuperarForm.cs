﻿using logica;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace login
{
    public partial class recuperarForm : Form
    {
        n_user l_User = new n_user();

        public recuperarForm()
        {
            InitializeComponent();
        }

        private void recuperar_Load(object sender, EventArgs e)
        {

        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnBuscarUsuario_Click(object sender, EventArgs e)
        {
            string name = txtUser.Text;

            if (l_User.searchUser(name))
            {
                lbMensaje.Text = "Usuario encontrado";
                lbMensaje.ForeColor = Color.Green;
                lbforLastPassword.Visible = true;
                txtLastPassword.Visible=true;
                txtForNewPassword.Visible = true;
                txtNewPassword.Visible = true;
                btnForConfirmNewPassword.Visible = true;
                txtLastPassword.Focus();
            }
            else
            {
                txtForNewPassword.Visible = false;
                txtNewPassword.Visible = false;
                btnForConfirmNewPassword.Visible = false;
                lbMensajeForNewPassword.Visible = false;
                lbMensaje.Text = "Usuario no encontrado";
                lbMensaje.ForeColor = Color.Red;
                txtUser.Focus();
            }
        }

        private void btnForConfirmNewPassword_Click(object sender, EventArgs e)
        {
            string user = txtUser.Text;
            string lastPassword = txtLastPassword.Text;
            string newPassword = txtNewPassword.Text;

            

            if(!string.IsNullOrEmpty(lastPassword) && !string.IsNullOrEmpty(newPassword))
            {
                if(l_User.changePassword(user, lastPassword, newPassword))
                {
                    MessageBox.Show("Cambio realizado");
                    btnIrLogin.Visible = true;
                    btnForConfirmNewPassword.Visible= false;
                    btnCancelar.Visible = false; 
                    //Close();
                }

            }
            if (string.IsNullOrEmpty(lastPassword))
            {
                // si esta vacio
                lbMensajeForLastPassword.ForeColor = Color.Red;
                lbMensajeForLastPassword.Text = "Campo vacio";
                txtLastPassword.Focus();
            }
            else
            {
                lbMensajeForLastPassword.ForeColor = Color.Green;
                lbMensajeForLastPassword.Text = "Campo completado";
                txtForNewPassword.Focus();
            }

            if (string.IsNullOrEmpty(newPassword))
            {
                lbMensajeForNewPassword.ForeColor = Color.Red;
                lbMensajeForNewPassword.Text = "Campo vacio";
                if (!string.IsNullOrEmpty(lastPassword))
                {
                    txtNewPassword.Focus();
                }
                txtLastPassword.Focus();

            }
            else
            {
                lbMensajeForNewPassword.ForeColor = Color.Green;
                lbMensajeForNewPassword.Text = "Campo completado";
                btnForConfirmNewPassword.Focus();
            }

        }

        private void btnIrLogin_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
