﻿namespace login
{
    partial class main
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControlPrincipal = new System.Windows.Forms.TabControl();
            this.tabPageInicio = new System.Windows.Forms.TabPage();
            this.btnMoverArchivos = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.btnMoverAempresaEliminarEmpresa = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.btnMoverAempresaCrear = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.treeFiles = new System.Windows.Forms.TreeView();
            this.tabPageArchivos = new System.Windows.Forms.TabPage();
            this.label16 = new System.Windows.Forms.Label();
            this.comboxEmpresasUploadFile = new System.Windows.Forms.ComboBox();
            this.btnUpdateUserFiles = new System.Windows.Forms.Button();
            this.filesForUser = new System.Windows.Forms.DataGridView();
            this.btnSubir = new System.Windows.Forms.Button();
            this.txtRuta = new System.Windows.Forms.TextBox();
            this.btnSelect = new System.Windows.Forms.Button();
            this.tabPageEmpresas = new System.Windows.Forms.TabPage();
            this.tabControlToGestionDeEmpresas = new System.Windows.Forms.TabControl();
            this.tabcrearEmpresa = new System.Windows.Forms.TabPage();
            this.btnCrearEmpresa = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.txtCrearEmpresa = new System.Windows.Forms.TextBox();
            this.tabeliminarEmpresa = new System.Windows.Forms.TabPage();
            this.label18 = new System.Windows.Forms.Label();
            this.comBoxEliminarEmpresa = new System.Windows.Forms.ComboBox();
            this.btnEliminarEmpresa = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.btnActualizarEmpresas = new System.Windows.Forms.Button();
            this.dataGridViewforAllEmpresas = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel3 = new System.Windows.Forms.Panel();
            this.allUsers = new System.Windows.Forms.DataGridView();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.txtIdEditar = new System.Windows.Forms.TextBox();
            this.tabControlToAdmin = new System.Windows.Forms.TabControl();
            this.tabHome = new System.Windows.Forms.TabPage();
            this.label7 = new System.Windows.Forms.Label();
            this.tabCrearUsuario = new System.Windows.Forms.TabPage();
            this.comBoxAcceso = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.comBoxPermisos = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtUserPasswordToNewUser = new System.Windows.Forms.TextBox();
            this.txtUserNameToNewUser = new System.Windows.Forms.TextBox();
            this.btnCrearUsuario = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tabEditar = new System.Windows.Forms.TabPage();
            this.comBoxEditarUser = new System.Windows.Forms.ComboBox();
            this.btnEditarCancelar = new System.Windows.Forms.Button();
            this.comBoxEditarAcceso = new System.Windows.Forms.ComboBox();
            this.lbForEditarAcceso = new System.Windows.Forms.Label();
            this.lbForEdit = new System.Windows.Forms.Label();
            this.btnBuscarUsuario = new System.Windows.Forms.Button();
            this.txtForMessageEditar = new System.Windows.Forms.Label();
            this.comBoxEditarPermisos = new System.Windows.Forms.ComboBox();
            this.lbForEditarPermisos = new System.Windows.Forms.Label();
            this.txtEditPassword = new System.Windows.Forms.TextBox();
            this.txtEditName = new System.Windows.Forms.TextBox();
            this.btnGuardarCambios = new System.Windows.Forms.Button();
            this.lbForEditarName = new System.Windows.Forms.Label();
            this.lbForEditarPassword = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tabEliminarUsuario = new System.Windows.Forms.TabPage();
            this.comBoxUserForDelete = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnEliminarUser = new System.Windows.Forms.Button();
            this.txtUserId = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnSalir = new System.Windows.Forms.Button();
            this.btnCerrarSesion = new System.Windows.Forms.Button();
            this.tabControlPrincipal.SuspendLayout();
            this.tabPageInicio.SuspendLayout();
            this.tabPageArchivos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.filesForUser)).BeginInit();
            this.tabPageEmpresas.SuspendLayout();
            this.tabControlToGestionDeEmpresas.SuspendLayout();
            this.tabcrearEmpresa.SuspendLayout();
            this.tabeliminarEmpresa.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewforAllEmpresas)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.allUsers)).BeginInit();
            this.tabControlToAdmin.SuspendLayout();
            this.tabHome.SuspendLayout();
            this.tabCrearUsuario.SuspendLayout();
            this.tabEditar.SuspendLayout();
            this.tabEliminarUsuario.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControlPrincipal
            // 
            this.tabControlPrincipal.Controls.Add(this.tabPageInicio);
            this.tabControlPrincipal.Controls.Add(this.tabPageArchivos);
            this.tabControlPrincipal.Controls.Add(this.tabPageEmpresas);
            this.tabControlPrincipal.Controls.Add(this.tabPage2);
            this.tabControlPrincipal.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tabControlPrincipal.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControlPrincipal.ItemSize = new System.Drawing.Size(70, 26);
            this.tabControlPrincipal.Location = new System.Drawing.Point(0, 30);
            this.tabControlPrincipal.Multiline = true;
            this.tabControlPrincipal.Name = "tabControlPrincipal";
            this.tabControlPrincipal.Padding = new System.Drawing.Point(20, 1);
            this.tabControlPrincipal.SelectedIndex = 0;
            this.tabControlPrincipal.Size = new System.Drawing.Size(1014, 631);
            this.tabControlPrincipal.TabIndex = 2;
            // 
            // tabPageInicio
            // 
            this.tabPageInicio.BackColor = System.Drawing.Color.White;
            this.tabPageInicio.Controls.Add(this.btnMoverArchivos);
            this.tabPageInicio.Controls.Add(this.label17);
            this.tabPageInicio.Controls.Add(this.label15);
            this.tabPageInicio.Controls.Add(this.btnMoverAempresaEliminarEmpresa);
            this.tabPageInicio.Controls.Add(this.label13);
            this.tabPageInicio.Controls.Add(this.btnMoverAempresaCrear);
            this.tabPageInicio.Controls.Add(this.button2);
            this.tabPageInicio.Controls.Add(this.label11);
            this.tabPageInicio.Controls.Add(this.treeFiles);
            this.tabPageInicio.Location = new System.Drawing.Point(4, 30);
            this.tabPageInicio.Name = "tabPageInicio";
            this.tabPageInicio.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageInicio.Size = new System.Drawing.Size(1006, 597);
            this.tabPageInicio.TabIndex = 0;
            this.tabPageInicio.Text = "Inicio";
            // 
            // btnMoverArchivos
            // 
            this.btnMoverArchivos.Location = new System.Drawing.Point(102, 242);
            this.btnMoverArchivos.Name = "btnMoverArchivos";
            this.btnMoverArchivos.Size = new System.Drawing.Size(133, 32);
            this.btnMoverArchivos.TabIndex = 24;
            this.btnMoverArchivos.Text = "subir archivos";
            this.btnMoverArchivos.UseVisualStyleBackColor = true;
            this.btnMoverArchivos.Click += new System.EventHandler(this.btnMoverArchivos_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(64, 219);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(102, 21);
            this.label17.TabIndex = 23;
            this.label17.Text = "Para archivos";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(64, 45);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(104, 21);
            this.label15.TabIndex = 22;
            this.label15.Text = "Para empresa";
            // 
            // btnMoverAempresaEliminarEmpresa
            // 
            this.btnMoverAempresaEliminarEmpresa.Location = new System.Drawing.Point(102, 106);
            this.btnMoverAempresaEliminarEmpresa.Name = "btnMoverAempresaEliminarEmpresa";
            this.btnMoverAempresaEliminarEmpresa.Size = new System.Drawing.Size(133, 32);
            this.btnMoverAempresaEliminarEmpresa.TabIndex = 21;
            this.btnMoverAempresaEliminarEmpresa.Text = "Eliminar empresa";
            this.btnMoverAempresaEliminarEmpresa.UseVisualStyleBackColor = true;
            this.btnMoverAempresaEliminarEmpresa.Click += new System.EventHandler(this.btnMoverAempresaEliminarEmpresa_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Segoe UI Semibold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(19, 15);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(216, 30);
            this.label13.TabIndex = 20;
            this.label13.Text = "Opciones disponibles";
            // 
            // btnMoverAempresaCrear
            // 
            this.btnMoverAempresaCrear.BackColor = System.Drawing.Color.White;
            this.btnMoverAempresaCrear.ForeColor = System.Drawing.Color.Black;
            this.btnMoverAempresaCrear.Location = new System.Drawing.Point(102, 68);
            this.btnMoverAempresaCrear.Name = "btnMoverAempresaCrear";
            this.btnMoverAempresaCrear.Size = new System.Drawing.Size(133, 32);
            this.btnMoverAempresaCrear.TabIndex = 19;
            this.btnMoverAempresaCrear.Text = "Crear empresa";
            this.btnMoverAempresaCrear.UseVisualStyleBackColor = false;
            this.btnMoverAempresaCrear.Click += new System.EventHandler(this.btnMoverAempresaCrear_Click);
            this.btnMoverAempresaCrear.MouseLeave += new System.EventHandler(this.btnMoverAempresaCrear_MouseLeave);
            this.btnMoverAempresaCrear.MouseHover += new System.EventHandler(this.btnMoverAempresaCrear_MouseHover_1);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.button2.Location = new System.Drawing.Point(513, 59);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(88, 30);
            this.button2.TabIndex = 18;
            this.button2.Text = "actualizar";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.White;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.label11.Location = new System.Drawing.Point(509, 27);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(138, 21);
            this.label11.TabIndex = 17;
            this.label11.Text = "Espacio de Trabajo";
            // 
            // treeFiles
            // 
            this.treeFiles.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.treeFiles.Location = new System.Drawing.Point(513, 106);
            this.treeFiles.Name = "treeFiles";
            this.treeFiles.Size = new System.Drawing.Size(476, 464);
            this.treeFiles.TabIndex = 16;
            this.treeFiles.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeFiles_AfterSelect);
            this.treeFiles.NodeMouseDoubleClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.treeFiles_NodeMouseDoubleClick);
            // 
            // tabPageArchivos
            // 
            this.tabPageArchivos.BackColor = System.Drawing.Color.White;
            this.tabPageArchivos.Controls.Add(this.label16);
            this.tabPageArchivos.Controls.Add(this.comboxEmpresasUploadFile);
            this.tabPageArchivos.Controls.Add(this.btnUpdateUserFiles);
            this.tabPageArchivos.Controls.Add(this.filesForUser);
            this.tabPageArchivos.Controls.Add(this.btnSubir);
            this.tabPageArchivos.Controls.Add(this.txtRuta);
            this.tabPageArchivos.Controls.Add(this.btnSelect);
            this.tabPageArchivos.Location = new System.Drawing.Point(4, 30);
            this.tabPageArchivos.Name = "tabPageArchivos";
            this.tabPageArchivos.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageArchivos.Size = new System.Drawing.Size(1006, 597);
            this.tabPageArchivos.TabIndex = 1;
            this.tabPageArchivos.Text = "Archivos";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(336, 504);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(73, 21);
            this.label16.TabIndex = 14;
            this.label16.Text = "Empresa:";
            // 
            // comboxEmpresasUploadFile
            // 
            this.comboxEmpresasUploadFile.FormattingEnabled = true;
            this.comboxEmpresasUploadFile.Location = new System.Drawing.Point(411, 500);
            this.comboxEmpresasUploadFile.Name = "comboxEmpresasUploadFile";
            this.comboxEmpresasUploadFile.Size = new System.Drawing.Size(248, 29);
            this.comboxEmpresasUploadFile.TabIndex = 13;
            // 
            // btnUpdateUserFiles
            // 
            this.btnUpdateUserFiles.Location = new System.Drawing.Point(851, 544);
            this.btnUpdateUserFiles.Name = "btnUpdateUserFiles";
            this.btnUpdateUserFiles.Size = new System.Drawing.Size(143, 34);
            this.btnUpdateUserFiles.TabIndex = 12;
            this.btnUpdateUserFiles.Text = "Actualizar";
            this.btnUpdateUserFiles.UseVisualStyleBackColor = true;
            this.btnUpdateUserFiles.Click += new System.EventHandler(this.btnUpdateUserFiles_Click);
            // 
            // filesForUser
            // 
            this.filesForUser.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.filesForUser.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.filesForUser.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.filesForUser.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            this.filesForUser.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.filesForUser.Location = new System.Drawing.Point(12, 18);
            this.filesForUser.Name = "filesForUser";
            this.filesForUser.ReadOnly = true;
            this.filesForUser.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            this.filesForUser.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.filesForUser.Size = new System.Drawing.Size(982, 477);
            this.filesForUser.TabIndex = 11;
            // 
            // btnSubir
            // 
            this.btnSubir.Location = new System.Drawing.Point(174, 544);
            this.btnSubir.Name = "btnSubir";
            this.btnSubir.Size = new System.Drawing.Size(136, 33);
            this.btnSubir.TabIndex = 10;
            this.btnSubir.Text = "subir archivo";
            this.btnSubir.UseVisualStyleBackColor = true;
            this.btnSubir.Visible = false;
            this.btnSubir.Click += new System.EventHandler(this.btnSubir_Click);
            // 
            // txtRuta
            // 
            this.txtRuta.Enabled = false;
            this.txtRuta.Location = new System.Drawing.Point(12, 501);
            this.txtRuta.Name = "txtRuta";
            this.txtRuta.Size = new System.Drawing.Size(298, 29);
            this.txtRuta.TabIndex = 9;
            // 
            // btnSelect
            // 
            this.btnSelect.Location = new System.Drawing.Point(12, 543);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(143, 34);
            this.btnSelect.TabIndex = 8;
            this.btnSelect.Text = "seleccionar archivo";
            this.btnSelect.UseVisualStyleBackColor = true;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // tabPageEmpresas
            // 
            this.tabPageEmpresas.BackColor = System.Drawing.Color.White;
            this.tabPageEmpresas.Controls.Add(this.tabControlToGestionDeEmpresas);
            this.tabPageEmpresas.Controls.Add(this.btnActualizarEmpresas);
            this.tabPageEmpresas.Controls.Add(this.dataGridViewforAllEmpresas);
            this.tabPageEmpresas.Location = new System.Drawing.Point(4, 30);
            this.tabPageEmpresas.Name = "tabPageEmpresas";
            this.tabPageEmpresas.Size = new System.Drawing.Size(1006, 597);
            this.tabPageEmpresas.TabIndex = 2;
            this.tabPageEmpresas.Text = "Empresa";
            // 
            // tabControlToGestionDeEmpresas
            // 
            this.tabControlToGestionDeEmpresas.Controls.Add(this.tabcrearEmpresa);
            this.tabControlToGestionDeEmpresas.Controls.Add(this.tabeliminarEmpresa);
            this.tabControlToGestionDeEmpresas.Location = new System.Drawing.Point(17, 21);
            this.tabControlToGestionDeEmpresas.Name = "tabControlToGestionDeEmpresas";
            this.tabControlToGestionDeEmpresas.SelectedIndex = 0;
            this.tabControlToGestionDeEmpresas.Size = new System.Drawing.Size(421, 542);
            this.tabControlToGestionDeEmpresas.TabIndex = 13;
            // 
            // tabcrearEmpresa
            // 
            this.tabcrearEmpresa.BackColor = System.Drawing.Color.White;
            this.tabcrearEmpresa.Controls.Add(this.btnCrearEmpresa);
            this.tabcrearEmpresa.Controls.Add(this.label10);
            this.tabcrearEmpresa.Controls.Add(this.txtCrearEmpresa);
            this.tabcrearEmpresa.Location = new System.Drawing.Point(4, 30);
            this.tabcrearEmpresa.Name = "tabcrearEmpresa";
            this.tabcrearEmpresa.Padding = new System.Windows.Forms.Padding(3);
            this.tabcrearEmpresa.Size = new System.Drawing.Size(413, 508);
            this.tabcrearEmpresa.TabIndex = 1;
            this.tabcrearEmpresa.Text = "Crear Empresa";
            // 
            // btnCrearEmpresa
            // 
            this.btnCrearEmpresa.Location = new System.Drawing.Point(238, 461);
            this.btnCrearEmpresa.Name = "btnCrearEmpresa";
            this.btnCrearEmpresa.Size = new System.Drawing.Size(157, 28);
            this.btnCrearEmpresa.TabIndex = 2;
            this.btnCrearEmpresa.Text = "Crear Empresa";
            this.btnCrearEmpresa.UseVisualStyleBackColor = true;
            this.btnCrearEmpresa.Click += new System.EventHandler(this.btnCrearEmpresa_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(78, 109);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(70, 21);
            this.label10.TabIndex = 1;
            this.label10.Text = "Empresa";
            // 
            // txtCrearEmpresa
            // 
            this.txtCrearEmpresa.Location = new System.Drawing.Point(166, 109);
            this.txtCrearEmpresa.Name = "txtCrearEmpresa";
            this.txtCrearEmpresa.Size = new System.Drawing.Size(179, 29);
            this.txtCrearEmpresa.TabIndex = 0;
            // 
            // tabeliminarEmpresa
            // 
            this.tabeliminarEmpresa.BackColor = System.Drawing.Color.White;
            this.tabeliminarEmpresa.Controls.Add(this.label18);
            this.tabeliminarEmpresa.Controls.Add(this.comBoxEliminarEmpresa);
            this.tabeliminarEmpresa.Controls.Add(this.btnEliminarEmpresa);
            this.tabeliminarEmpresa.Controls.Add(this.label12);
            this.tabeliminarEmpresa.Location = new System.Drawing.Point(4, 30);
            this.tabeliminarEmpresa.Name = "tabeliminarEmpresa";
            this.tabeliminarEmpresa.Size = new System.Drawing.Size(413, 508);
            this.tabeliminarEmpresa.TabIndex = 2;
            this.tabeliminarEmpresa.Text = "Eliminar Empresa";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(27, 76);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(177, 21);
            this.label18.TabIndex = 23;
            this.label18.Text = "Seleccione una empresa";
            // 
            // comBoxEliminarEmpresa
            // 
            this.comBoxEliminarEmpresa.FormattingEnabled = true;
            this.comBoxEliminarEmpresa.Location = new System.Drawing.Point(103, 115);
            this.comBoxEliminarEmpresa.Name = "comBoxEliminarEmpresa";
            this.comBoxEliminarEmpresa.Size = new System.Drawing.Size(275, 29);
            this.comBoxEliminarEmpresa.TabIndex = 6;
            // 
            // btnEliminarEmpresa
            // 
            this.btnEliminarEmpresa.Location = new System.Drawing.Point(237, 459);
            this.btnEliminarEmpresa.Name = "btnEliminarEmpresa";
            this.btnEliminarEmpresa.Size = new System.Drawing.Size(157, 28);
            this.btnEliminarEmpresa.TabIndex = 5;
            this.btnEliminarEmpresa.Text = "Eliminar Empresa";
            this.btnEliminarEmpresa.UseVisualStyleBackColor = true;
            this.btnEliminarEmpresa.Click += new System.EventHandler(this.btnEliminarEmpresa_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(27, 118);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(70, 21);
            this.label12.TabIndex = 4;
            this.label12.Text = "Empresa";
            // 
            // btnActualizarEmpresas
            // 
            this.btnActualizarEmpresas.Location = new System.Drawing.Point(459, 18);
            this.btnActualizarEmpresas.Name = "btnActualizarEmpresas";
            this.btnActualizarEmpresas.Size = new System.Drawing.Size(128, 30);
            this.btnActualizarEmpresas.TabIndex = 12;
            this.btnActualizarEmpresas.Text = "Actualizar";
            this.btnActualizarEmpresas.UseVisualStyleBackColor = true;
            this.btnActualizarEmpresas.Click += new System.EventHandler(this.btnActualizarEmpresas_Click_1);
            // 
            // dataGridViewforAllEmpresas
            // 
            this.dataGridViewforAllEmpresas.AllowUserToAddRows = false;
            this.dataGridViewforAllEmpresas.AllowUserToDeleteRows = false;
            this.dataGridViewforAllEmpresas.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewforAllEmpresas.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridViewforAllEmpresas.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridViewforAllEmpresas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewforAllEmpresas.Location = new System.Drawing.Point(459, 54);
            this.dataGridViewforAllEmpresas.Name = "dataGridViewforAllEmpresas";
            this.dataGridViewforAllEmpresas.ReadOnly = true;
            this.dataGridViewforAllEmpresas.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dataGridViewforAllEmpresas.Size = new System.Drawing.Size(531, 522);
            this.dataGridViewforAllEmpresas.TabIndex = 11;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.White;
            this.tabPage2.Controls.Add(this.panel3);
            this.tabPage2.Controls.Add(this.tabControlToAdmin);
            this.tabPage2.Location = new System.Drawing.Point(4, 30);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(1006, 597);
            this.tabPage2.TabIndex = 3;
            this.tabPage2.Text = "Gestion de Usuarios";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.allUsers);
            this.panel3.Controls.Add(this.btnUpdate);
            this.panel3.Controls.Add(this.txtIdEditar);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(422, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(584, 597);
            this.panel3.TabIndex = 7;
            // 
            // allUsers
            // 
            this.allUsers.AllowUserToAddRows = false;
            this.allUsers.AllowUserToDeleteRows = false;
            this.allUsers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.allUsers.Location = new System.Drawing.Point(24, 43);
            this.allUsers.Name = "allUsers";
            this.allUsers.ReadOnly = true;
            this.allUsers.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.allUsers.Size = new System.Drawing.Size(531, 506);
            this.allUsers.TabIndex = 0;
            this.allUsers.TabStop = false;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(24, 10);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(92, 27);
            this.btnUpdate.TabIndex = 1;
            this.btnUpdate.Text = "Actualizar";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // txtIdEditar
            // 
            this.txtIdEditar.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtIdEditar.Location = new System.Drawing.Point(122, 10);
            this.txtIdEditar.Name = "txtIdEditar";
            this.txtIdEditar.Size = new System.Drawing.Size(181, 29);
            this.txtIdEditar.TabIndex = 19;
            this.txtIdEditar.Visible = false;
            // 
            // tabControlToAdmin
            // 
            this.tabControlToAdmin.Controls.Add(this.tabHome);
            this.tabControlToAdmin.Controls.Add(this.tabCrearUsuario);
            this.tabControlToAdmin.Controls.Add(this.tabEditar);
            this.tabControlToAdmin.Controls.Add(this.tabEliminarUsuario);
            this.tabControlToAdmin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tabControlToAdmin.Dock = System.Windows.Forms.DockStyle.Left;
            this.tabControlToAdmin.Location = new System.Drawing.Point(0, 0);
            this.tabControlToAdmin.Name = "tabControlToAdmin";
            this.tabControlToAdmin.Padding = new System.Drawing.Point(20, 3);
            this.tabControlToAdmin.SelectedIndex = 0;
            this.tabControlToAdmin.Size = new System.Drawing.Size(422, 597);
            this.tabControlToAdmin.TabIndex = 6;
            // 
            // tabHome
            // 
            this.tabHome.BackColor = System.Drawing.Color.White;
            this.tabHome.Controls.Add(this.label7);
            this.tabHome.Location = new System.Drawing.Point(4, 30);
            this.tabHome.Name = "tabHome";
            this.tabHome.Size = new System.Drawing.Size(414, 563);
            this.tabHome.TabIndex = 2;
            this.tabHome.Text = "Inicio";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(26, 27);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 21);
            this.label7.TabIndex = 17;
            this.label7.Text = "bienvenido";
            // 
            // tabCrearUsuario
            // 
            this.tabCrearUsuario.BackColor = System.Drawing.Color.White;
            this.tabCrearUsuario.Controls.Add(this.comBoxAcceso);
            this.tabCrearUsuario.Controls.Add(this.label14);
            this.tabCrearUsuario.Controls.Add(this.label5);
            this.tabCrearUsuario.Controls.Add(this.comBoxPermisos);
            this.tabCrearUsuario.Controls.Add(this.label4);
            this.tabCrearUsuario.Controls.Add(this.txtUserPasswordToNewUser);
            this.tabCrearUsuario.Controls.Add(this.txtUserNameToNewUser);
            this.tabCrearUsuario.Controls.Add(this.btnCrearUsuario);
            this.tabCrearUsuario.Controls.Add(this.label3);
            this.tabCrearUsuario.Controls.Add(this.label2);
            this.tabCrearUsuario.ForeColor = System.Drawing.Color.White;
            this.tabCrearUsuario.Location = new System.Drawing.Point(4, 30);
            this.tabCrearUsuario.Name = "tabCrearUsuario";
            this.tabCrearUsuario.Padding = new System.Windows.Forms.Padding(3);
            this.tabCrearUsuario.Size = new System.Drawing.Size(414, 563);
            this.tabCrearUsuario.TabIndex = 0;
            this.tabCrearUsuario.Text = "Crear";
            // 
            // comBoxAcceso
            // 
            this.comBoxAcceso.BackColor = System.Drawing.Color.WhiteSmoke;
            this.comBoxAcceso.ForeColor = System.Drawing.SystemColors.ControlText;
            this.comBoxAcceso.FormattingEnabled = true;
            this.comBoxAcceso.Items.AddRange(new object[] {
            "Activado",
            "Denegado"});
            this.comBoxAcceso.Location = new System.Drawing.Point(112, 322);
            this.comBoxAcceso.Name = "comBoxAcceso";
            this.comBoxAcceso.Size = new System.Drawing.Size(185, 29);
            this.comBoxAcceso.TabIndex = 18;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label14.Location = new System.Drawing.Point(94, 298);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(60, 20);
            this.label14.TabIndex = 17;
            this.label14.Text = "Acceso:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(82, 68);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(231, 21);
            this.label5.TabIndex = 16;
            this.label5.Text = "Ingrese datos del nuevo usuario";
            // 
            // comBoxPermisos
            // 
            this.comBoxPermisos.BackColor = System.Drawing.Color.WhiteSmoke;
            this.comBoxPermisos.ForeColor = System.Drawing.SystemColors.ControlText;
            this.comBoxPermisos.FormattingEnabled = true;
            this.comBoxPermisos.Items.AddRange(new object[] {
            "Administrador",
            "Usuario"});
            this.comBoxPermisos.Location = new System.Drawing.Point(112, 255);
            this.comBoxPermisos.Name = "comBoxPermisos";
            this.comBoxPermisos.Size = new System.Drawing.Size(185, 29);
            this.comBoxPermisos.TabIndex = 15;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.Location = new System.Drawing.Point(94, 231);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 20);
            this.label4.TabIndex = 14;
            this.label4.Text = "Permisos:";
            // 
            // txtUserPasswordToNewUser
            // 
            this.txtUserPasswordToNewUser.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtUserPasswordToNewUser.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtUserPasswordToNewUser.Location = new System.Drawing.Point(112, 191);
            this.txtUserPasswordToNewUser.Name = "txtUserPasswordToNewUser";
            this.txtUserPasswordToNewUser.Size = new System.Drawing.Size(185, 29);
            this.txtUserPasswordToNewUser.TabIndex = 13;
            // 
            // txtUserNameToNewUser
            // 
            this.txtUserNameToNewUser.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtUserNameToNewUser.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtUserNameToNewUser.Location = new System.Drawing.Point(112, 129);
            this.txtUserNameToNewUser.Name = "txtUserNameToNewUser";
            this.txtUserNameToNewUser.Size = new System.Drawing.Size(185, 29);
            this.txtUserNameToNewUser.TabIndex = 12;
            // 
            // btnCrearUsuario
            // 
            this.btnCrearUsuario.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnCrearUsuario.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnCrearUsuario.Location = new System.Drawing.Point(150, 379);
            this.btnCrearUsuario.Name = "btnCrearUsuario";
            this.btnCrearUsuario.Size = new System.Drawing.Size(109, 27);
            this.btnCrearUsuario.TabIndex = 11;
            this.btnCrearUsuario.Text = "Crear Usuario";
            this.btnCrearUsuario.UseVisualStyleBackColor = false;
            this.btnCrearUsuario.Click += new System.EventHandler(this.btnCrearUsuario_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Location = new System.Drawing.Point(94, 105);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(157, 21);
            this.label3.TabIndex = 10;
            this.label3.Text = "Nombre de Usuario:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Location = new System.Drawing.Point(94, 167);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 20);
            this.label2.TabIndex = 9;
            this.label2.Text = "Contraseña:";
            // 
            // tabEditar
            // 
            this.tabEditar.BackColor = System.Drawing.Color.White;
            this.tabEditar.Controls.Add(this.comBoxEditarUser);
            this.tabEditar.Controls.Add(this.btnEditarCancelar);
            this.tabEditar.Controls.Add(this.comBoxEditarAcceso);
            this.tabEditar.Controls.Add(this.lbForEditarAcceso);
            this.tabEditar.Controls.Add(this.lbForEdit);
            this.tabEditar.Controls.Add(this.btnBuscarUsuario);
            this.tabEditar.Controls.Add(this.txtForMessageEditar);
            this.tabEditar.Controls.Add(this.comBoxEditarPermisos);
            this.tabEditar.Controls.Add(this.lbForEditarPermisos);
            this.tabEditar.Controls.Add(this.txtEditPassword);
            this.tabEditar.Controls.Add(this.txtEditName);
            this.tabEditar.Controls.Add(this.btnGuardarCambios);
            this.tabEditar.Controls.Add(this.lbForEditarName);
            this.tabEditar.Controls.Add(this.lbForEditarPassword);
            this.tabEditar.Controls.Add(this.label8);
            this.tabEditar.Controls.Add(this.label9);
            this.tabEditar.Location = new System.Drawing.Point(4, 30);
            this.tabEditar.Name = "tabEditar";
            this.tabEditar.Padding = new System.Windows.Forms.Padding(3);
            this.tabEditar.Size = new System.Drawing.Size(414, 563);
            this.tabEditar.TabIndex = 3;
            this.tabEditar.Text = "Editar";
            // 
            // comBoxEditarUser
            // 
            this.comBoxEditarUser.FormattingEnabled = true;
            this.comBoxEditarUser.Location = new System.Drawing.Point(122, 67);
            this.comBoxEditarUser.Name = "comBoxEditarUser";
            this.comBoxEditarUser.Size = new System.Drawing.Size(181, 29);
            this.comBoxEditarUser.TabIndex = 20;
            // 
            // btnEditarCancelar
            // 
            this.btnEditarCancelar.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnEditarCancelar.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnEditarCancelar.Location = new System.Drawing.Point(222, 493);
            this.btnEditarCancelar.Name = "btnEditarCancelar";
            this.btnEditarCancelar.Size = new System.Drawing.Size(128, 27);
            this.btnEditarCancelar.TabIndex = 27;
            this.btnEditarCancelar.Text = "Cancelar";
            this.btnEditarCancelar.UseVisualStyleBackColor = false;
            this.btnEditarCancelar.Visible = false;
            this.btnEditarCancelar.Click += new System.EventHandler(this.btnEditarCancelar_Click);
            // 
            // comBoxEditarAcceso
            // 
            this.comBoxEditarAcceso.BackColor = System.Drawing.Color.WhiteSmoke;
            this.comBoxEditarAcceso.ForeColor = System.Drawing.SystemColors.ControlText;
            this.comBoxEditarAcceso.FormattingEnabled = true;
            this.comBoxEditarAcceso.Items.AddRange(new object[] {
            "Activado",
            "Denegado"});
            this.comBoxEditarAcceso.Location = new System.Drawing.Point(122, 392);
            this.comBoxEditarAcceso.Name = "comBoxEditarAcceso";
            this.comBoxEditarAcceso.Size = new System.Drawing.Size(185, 29);
            this.comBoxEditarAcceso.TabIndex = 25;
            this.comBoxEditarAcceso.Visible = false;
            // 
            // lbForEditarAcceso
            // 
            this.lbForEditarAcceso.AutoSize = true;
            this.lbForEditarAcceso.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbForEditarAcceso.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbForEditarAcceso.Location = new System.Drawing.Point(108, 368);
            this.lbForEditarAcceso.Name = "lbForEditarAcceso";
            this.lbForEditarAcceso.Size = new System.Drawing.Size(60, 20);
            this.lbForEditarAcceso.TabIndex = 31;
            this.lbForEditarAcceso.Text = "Acceso:";
            this.lbForEditarAcceso.Visible = false;
            // 
            // lbForEdit
            // 
            this.lbForEdit.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbForEdit.ForeColor = System.Drawing.Color.Black;
            this.lbForEdit.Location = new System.Drawing.Point(10, 442);
            this.lbForEdit.Name = "lbForEdit";
            this.lbForEdit.Size = new System.Drawing.Size(396, 30);
            this.lbForEdit.TabIndex = 30;
            this.lbForEdit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnBuscarUsuario
            // 
            this.btnBuscarUsuario.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnBuscarUsuario.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnBuscarUsuario.Location = new System.Drawing.Point(137, 116);
            this.btnBuscarUsuario.Name = "btnBuscarUsuario";
            this.btnBuscarUsuario.Size = new System.Drawing.Size(128, 27);
            this.btnBuscarUsuario.TabIndex = 21;
            this.btnBuscarUsuario.Text = "Editar usuario";
            this.btnBuscarUsuario.UseVisualStyleBackColor = false;
            this.btnBuscarUsuario.Click += new System.EventHandler(this.btnBuscarUsuario_Click);
            // 
            // txtForMessageEditar
            // 
            this.txtForMessageEditar.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtForMessageEditar.ForeColor = System.Drawing.Color.Black;
            this.txtForMessageEditar.Location = new System.Drawing.Point(10, 150);
            this.txtForMessageEditar.Name = "txtForMessageEditar";
            this.txtForMessageEditar.Size = new System.Drawing.Size(396, 28);
            this.txtForMessageEditar.TabIndex = 28;
            this.txtForMessageEditar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // comBoxEditarPermisos
            // 
            this.comBoxEditarPermisos.BackColor = System.Drawing.Color.WhiteSmoke;
            this.comBoxEditarPermisos.ForeColor = System.Drawing.SystemColors.ControlText;
            this.comBoxEditarPermisos.FormattingEnabled = true;
            this.comBoxEditarPermisos.Items.AddRange(new object[] {
            "Administrador",
            "Usuario"});
            this.comBoxEditarPermisos.Location = new System.Drawing.Point(122, 328);
            this.comBoxEditarPermisos.Name = "comBoxEditarPermisos";
            this.comBoxEditarPermisos.Size = new System.Drawing.Size(185, 29);
            this.comBoxEditarPermisos.TabIndex = 24;
            this.comBoxEditarPermisos.Visible = false;
            // 
            // lbForEditarPermisos
            // 
            this.lbForEditarPermisos.AutoSize = true;
            this.lbForEditarPermisos.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbForEditarPermisos.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbForEditarPermisos.Location = new System.Drawing.Point(108, 304);
            this.lbForEditarPermisos.Name = "lbForEditarPermisos";
            this.lbForEditarPermisos.Size = new System.Drawing.Size(73, 20);
            this.lbForEditarPermisos.TabIndex = 26;
            this.lbForEditarPermisos.Text = "Permisos:";
            this.lbForEditarPermisos.Visible = false;
            // 
            // txtEditPassword
            // 
            this.txtEditPassword.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtEditPassword.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtEditPassword.Location = new System.Drawing.Point(122, 264);
            this.txtEditPassword.Name = "txtEditPassword";
            this.txtEditPassword.Size = new System.Drawing.Size(185, 29);
            this.txtEditPassword.TabIndex = 23;
            this.txtEditPassword.Visible = false;
            // 
            // txtEditName
            // 
            this.txtEditName.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtEditName.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtEditName.Location = new System.Drawing.Point(122, 202);
            this.txtEditName.Name = "txtEditName";
            this.txtEditName.Size = new System.Drawing.Size(185, 29);
            this.txtEditName.TabIndex = 22;
            this.txtEditName.Visible = false;
            // 
            // btnGuardarCambios
            // 
            this.btnGuardarCambios.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnGuardarCambios.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnGuardarCambios.Location = new System.Drawing.Point(67, 493);
            this.btnGuardarCambios.Name = "btnGuardarCambios";
            this.btnGuardarCambios.Size = new System.Drawing.Size(131, 27);
            this.btnGuardarCambios.TabIndex = 26;
            this.btnGuardarCambios.Text = "Guardar cambios";
            this.btnGuardarCambios.UseVisualStyleBackColor = false;
            this.btnGuardarCambios.Visible = false;
            this.btnGuardarCambios.Click += new System.EventHandler(this.btnGuardarCambios_Click);
            // 
            // lbForEditarName
            // 
            this.lbForEditarName.AutoSize = true;
            this.lbForEditarName.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbForEditarName.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbForEditarName.Location = new System.Drawing.Point(108, 178);
            this.lbForEditarName.Name = "lbForEditarName";
            this.lbForEditarName.Size = new System.Drawing.Size(157, 21);
            this.lbForEditarName.TabIndex = 22;
            this.lbForEditarName.Text = "Nombre de Usuario:";
            this.lbForEditarName.Visible = false;
            // 
            // lbForEditarPassword
            // 
            this.lbForEditarPassword.AutoSize = true;
            this.lbForEditarPassword.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbForEditarPassword.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbForEditarPassword.Location = new System.Drawing.Point(108, 240);
            this.lbForEditarPassword.Name = "lbForEditarPassword";
            this.lbForEditarPassword.Size = new System.Drawing.Size(90, 20);
            this.lbForEditarPassword.TabIndex = 21;
            this.lbForEditarPassword.Text = "Contraseña:";
            this.lbForEditarPassword.Visible = false;
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(6, 10);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(261, 27);
            this.label8.TabIndex = 20;
            this.label8.Text = "Ingrese datos del usuario a editar";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(100, 43);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(63, 21);
            this.label9.TabIndex = 18;
            this.label9.Text = "User ID";
            // 
            // tabEliminarUsuario
            // 
            this.tabEliminarUsuario.BackColor = System.Drawing.Color.White;
            this.tabEliminarUsuario.Controls.Add(this.comBoxUserForDelete);
            this.tabEliminarUsuario.Controls.Add(this.label6);
            this.tabEliminarUsuario.Controls.Add(this.btnEliminarUser);
            this.tabEliminarUsuario.Controls.Add(this.txtUserId);
            this.tabEliminarUsuario.Controls.Add(this.label1);
            this.tabEliminarUsuario.Location = new System.Drawing.Point(4, 30);
            this.tabEliminarUsuario.Name = "tabEliminarUsuario";
            this.tabEliminarUsuario.Padding = new System.Windows.Forms.Padding(3);
            this.tabEliminarUsuario.Size = new System.Drawing.Size(414, 563);
            this.tabEliminarUsuario.TabIndex = 1;
            this.tabEliminarUsuario.Text = "Eliminar";
            // 
            // comBoxUserForDelete
            // 
            this.comBoxUserForDelete.FormattingEnabled = true;
            this.comBoxUserForDelete.Location = new System.Drawing.Point(119, 234);
            this.comBoxUserForDelete.Name = "comBoxUserForDelete";
            this.comBoxUserForDelete.Size = new System.Drawing.Size(178, 29);
            this.comBoxUserForDelete.TabIndex = 18;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(95, 138);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(229, 43);
            this.label6.TabIndex = 17;
            this.label6.Text = "Ingrese datos del usuario a eliminar";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnEliminarUser
            // 
            this.btnEliminarUser.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEliminarUser.Location = new System.Drawing.Point(169, 416);
            this.btnEliminarUser.Name = "btnEliminarUser";
            this.btnEliminarUser.Size = new System.Drawing.Size(81, 32);
            this.btnEliminarUser.TabIndex = 11;
            this.btnEliminarUser.Text = "Eliminar";
            this.btnEliminarUser.UseVisualStyleBackColor = true;
            this.btnEliminarUser.Click += new System.EventHandler(this.btnEliminarUser_Click);
            // 
            // txtUserId
            // 
            this.txtUserId.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtUserId.Location = new System.Drawing.Point(119, 281);
            this.txtUserId.Name = "txtUserId";
            this.txtUserId.Size = new System.Drawing.Size(181, 29);
            this.txtUserId.TabIndex = 10;
            this.txtUserId.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(115, 210);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 21);
            this.label1.TabIndex = 9;
            this.label1.Text = "User ID";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(24)))), ((int)(((byte)(68)))));
            this.panel1.Controls.Add(this.btnSalir);
            this.panel1.Controls.Add(this.btnCerrarSesion);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1014, 72);
            this.panel1.TabIndex = 6;
            // 
            // btnSalir
            // 
            this.btnSalir.BackColor = System.Drawing.Color.Black;
            this.btnSalir.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSalir.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSalir.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnSalir.ForeColor = System.Drawing.Color.Transparent;
            this.btnSalir.Location = new System.Drawing.Point(921, 3);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(81, 24);
            this.btnSalir.TabIndex = 2;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = false;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // btnCerrarSesion
            // 
            this.btnCerrarSesion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(24)))), ((int)(((byte)(68)))));
            this.btnCerrarSesion.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCerrarSesion.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnCerrarSesion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.btnCerrarSesion.Location = new System.Drawing.Point(800, 3);
            this.btnCerrarSesion.Name = "btnCerrarSesion";
            this.btnCerrarSesion.Size = new System.Drawing.Size(115, 24);
            this.btnCerrarSesion.TabIndex = 1;
            this.btnCerrarSesion.Text = "Cerrar Sesion ";
            this.btnCerrarSesion.UseVisualStyleBackColor = false;
            this.btnCerrarSesion.Click += new System.EventHandler(this.btnCerrarSesion_Click);
            // 
            // main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1014, 661);
            this.Controls.Add(this.tabControlPrincipal);
            this.Controls.Add(this.panel1);
            this.IsMdiContainer = true;
            this.MaximizeBox = false;
            this.Name = "main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "main";
            this.Load += new System.EventHandler(this.main_Load);
            this.tabControlPrincipal.ResumeLayout(false);
            this.tabPageInicio.ResumeLayout(false);
            this.tabPageInicio.PerformLayout();
            this.tabPageArchivos.ResumeLayout(false);
            this.tabPageArchivos.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.filesForUser)).EndInit();
            this.tabPageEmpresas.ResumeLayout(false);
            this.tabControlToGestionDeEmpresas.ResumeLayout(false);
            this.tabcrearEmpresa.ResumeLayout(false);
            this.tabcrearEmpresa.PerformLayout();
            this.tabeliminarEmpresa.ResumeLayout(false);
            this.tabeliminarEmpresa.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewforAllEmpresas)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.allUsers)).EndInit();
            this.tabControlToAdmin.ResumeLayout(false);
            this.tabHome.ResumeLayout(false);
            this.tabHome.PerformLayout();
            this.tabCrearUsuario.ResumeLayout(false);
            this.tabCrearUsuario.PerformLayout();
            this.tabEditar.ResumeLayout(false);
            this.tabEditar.PerformLayout();
            this.tabEliminarUsuario.ResumeLayout(false);
            this.tabEliminarUsuario.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TabControl tabControlPrincipal;
        private System.Windows.Forms.TabPage tabPageInicio;
        private System.Windows.Forms.TabPage tabPageArchivos;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnMoverArchivos;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnMoverAempresaEliminarEmpresa;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnMoverAempresaCrear;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TreeView treeFiles;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox comboxEmpresasUploadFile;
        private System.Windows.Forms.Button btnUpdateUserFiles;
        private System.Windows.Forms.DataGridView filesForUser;
        private System.Windows.Forms.Button btnSubir;
        private System.Windows.Forms.TextBox txtRuta;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.TabPage tabPageEmpresas;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabControl tabControlToGestionDeEmpresas;
        private System.Windows.Forms.TabPage tabcrearEmpresa;
        private System.Windows.Forms.Button btnCrearEmpresa;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtCrearEmpresa;
        private System.Windows.Forms.TabPage tabeliminarEmpresa;
        private System.Windows.Forms.Button btnEliminarEmpresa;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnActualizarEmpresas;
        private System.Windows.Forms.DataGridView dataGridViewforAllEmpresas;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridView allUsers;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.TabControl tabControlToAdmin;
        private System.Windows.Forms.TabPage tabHome;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TabPage tabCrearUsuario;
        private System.Windows.Forms.ComboBox comBoxAcceso;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comBoxPermisos;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtUserPasswordToNewUser;
        private System.Windows.Forms.TextBox txtUserNameToNewUser;
        private System.Windows.Forms.Button btnCrearUsuario;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabPage tabEditar;
        private System.Windows.Forms.Button btnEditarCancelar;
        private System.Windows.Forms.ComboBox comBoxEditarAcceso;
        private System.Windows.Forms.Label lbForEditarAcceso;
        private System.Windows.Forms.Label lbForEdit;
        private System.Windows.Forms.Button btnBuscarUsuario;
        private System.Windows.Forms.Label txtForMessageEditar;
        private System.Windows.Forms.ComboBox comBoxEditarPermisos;
        private System.Windows.Forms.Label lbForEditarPermisos;
        private System.Windows.Forms.TextBox txtEditPassword;
        private System.Windows.Forms.TextBox txtEditName;
        private System.Windows.Forms.Button btnGuardarCambios;
        private System.Windows.Forms.Label lbForEditarName;
        private System.Windows.Forms.Label lbForEditarPassword;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtIdEditar;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TabPage tabEliminarUsuario;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnEliminarUser;
        private System.Windows.Forms.TextBox txtUserId;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Button btnCerrarSesion;
        private System.Windows.Forms.ComboBox comBoxEliminarEmpresa;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ComboBox comBoxUserForDelete;
        private System.Windows.Forms.ComboBox comBoxEditarUser;
    }
}

